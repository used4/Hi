<?php
// index.php — Restricted Access
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>ACCESS DENIED</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Bebas+Neue&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --red:    #ff2222;
      --red2:   #ff5533;
      --dark:   #080808;
      --darker: #030303;
      --mono:   'Share Tech Mono', monospace;
    }

    html, body {
      height: 100%;
      background: var(--darker);
      color: #ccc;
      font-family: var(--mono);
      overflow: hidden;
      cursor: none;
    }

    /* Custom cursor */
    #cursor {
      position: fixed;
      width: 20px; height: 20px;
      border: 1px solid var(--red);
      border-radius: 50%;
      pointer-events: none;
      z-index: 9999;
      transform: translate(-50%, -50%);
      transition: width .15s, height .15s;
      mix-blend-mode: difference;
    }
    #cursor-dot {
      position: fixed;
      width: 4px; height: 4px;
      background: var(--red);
      border-radius: 50%;
      pointer-events: none;
      z-index: 9999;
      transform: translate(-50%, -50%);
    }

    /* Scanlines */
    body::before {
      content: '';
      position: fixed;
      inset: 0;
      background: repeating-linear-gradient(
        0deg,
        rgba(0,0,0,0.18) 0px,
        rgba(0,0,0,0.18) 1px,
        transparent 1px,
        transparent 3px
      );
      pointer-events: none;
      z-index: 100;
    }

    /* Vignette */
    body::after {
      content: '';
      position: fixed;
      inset: 0;
      background: radial-gradient(ellipse at center, transparent 40%, rgba(0,0,0,0.85) 100%);
      pointer-events: none;
      z-index: 100;
    }

    /* Grid background */
    #grid {
      position: fixed;
      inset: 0;
      background-image:
        linear-gradient(rgba(255,34,34,0.04) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255,34,34,0.04) 1px, transparent 1px);
      background-size: 50px 50px;
      animation: gridPulse 4s ease-in-out infinite;
      z-index: 0;
    }
    @keyframes gridPulse {
      0%,100% { opacity: .6; }
      50%      { opacity: 1; }
    }

    /* Glitch overlay */
    #glitch-overlay {
      position: fixed;
      inset: 0;
      z-index: 2;
      pointer-events: none;
      animation: glitchOverlay 8s steps(1) infinite;
    }
    @keyframes glitchOverlay {
      0%,94%,100% { opacity: 0; }
      95% {
        opacity: 1;
        background: linear-gradient(transparent 48%, rgba(255,30,30,0.06) 48%, rgba(255,30,30,0.06) 52%, transparent 52%);
      }
      96% { opacity: 0; }
      97% {
        opacity: 1;
        background: linear-gradient(transparent 20%, rgba(255,30,30,0.04) 20%, rgba(255,30,30,0.04) 23%, transparent 23%);
      }
    }

    /* Main layout */
    main {
      position: relative;
      z-index: 10;
      height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 2rem;
      text-align: center;
    }

    /* Warning symbol */
    .warning-ring {
      position: relative;
      width: 100px;
      height: 100px;
      margin: 0 auto 2rem;
      animation: ringPulse 2s ease-in-out infinite;
    }
    @keyframes ringPulse {
      0%,100% { filter: drop-shadow(0 0 8px var(--red)); }
      50%      { filter: drop-shadow(0 0 28px var(--red)); }
    }

    .warning-ring svg { width: 100%; height: 100%; }

    /* Code badge */
    .code-badge {
      font-size: .65rem;
      letter-spacing: .2em;
      color: var(--red);
      margin-bottom: .8rem;
      animation: blink 1.2s step-start infinite;
    }
    @keyframes blink {
      0%,100% { opacity: 1; }
      50%      { opacity: 0; }
    }

    /* Headline */
    h1 {
      font-family: 'Bebas Neue', sans-serif;
      font-size: clamp(3.5rem, 12vw, 7rem);
      letter-spacing: .04em;
      line-height: 1;
      color: #fff;
      text-shadow:
        0 0 20px rgba(255,34,34,0.6),
        0 0 60px rgba(255,34,34,0.2);
      animation: headlineGlitch 7s steps(1) infinite;
      margin-bottom: .5rem;
    }
    @keyframes headlineGlitch {
      0%,89%,100% { text-shadow: 0 0 20px rgba(255,34,34,0.6), 0 0 60px rgba(255,34,34,0.2); transform: none; }
      90%  { transform: translate(-3px,0); color: var(--red2); }
      91%  { transform: translate(3px,0);  color: #fff; }
      92%  { transform: translate(-1px,0) skewX(-5deg); }
      93%  { transform: none; }
    }

    .sub-headline {
      font-family: 'Bebas Neue', sans-serif;
      font-size: clamp(1.2rem, 4vw, 2rem);
      letter-spacing: .25em;
      color: var(--red);
      margin-bottom: 2.5rem;
      opacity: .85;
    }

    /* Terminal log */
    .terminal {
      background: rgba(255,0,0,0.04);
      border: 1px solid rgba(255,34,34,0.2);
      border-radius: 6px;
      padding: 1.4rem 1.5rem 1.1rem;
      max-width: 480px;
      width: 100%;
      text-align: left;
      font-size: .72rem;
      line-height: 2;
      color: #888;
      margin-bottom: 2.5rem;
      position: relative;
    }
    .terminal::before {
      content: 'SYSTEM LOG';
      position: absolute;
      top: -.55rem; left: 1rem;
      font-size: .55rem;
      letter-spacing: .2em;
      color: rgba(255,34,34,0.5);
      background: var(--darker);
      padding: 0 .4rem;
    }

    .log-line { display: block; overflow: hidden; white-space: nowrap; }
    .log-line span { color: var(--red); }
    .log-line.ok span { color: #44ff88; }
    .log-line.warn span { color: #ffcc00; }

    .log-line:nth-child(1) { animation: reveal .1s .3s both; }
    .log-line:nth-child(2) { animation: reveal .1s .7s both; }
    .log-line:nth-child(3) { animation: reveal .1s 1.1s both; }
    .log-line:nth-child(4) { animation: reveal .1s 1.5s both; }
    .log-line:nth-child(5) { animation: reveal .1s 1.9s both; }
    .log-line:nth-child(6) { animation: reveal .1s 2.3s both; }

    @keyframes reveal {
      from { opacity: 0; transform: translateX(-6px); }
      to   { opacity: 1; transform: none; }
    }

    /* Buttons */
    .actions {
      display: flex;
      gap: 1rem;
      flex-wrap: wrap;
      justify-content: center;
      animation: reveal .3s 2.8s both;
    }

    .btn {
      font-family: var(--mono);
      font-size: .75rem;
      letter-spacing: .1em;
      padding: .65rem 1.6rem;
      border-radius: 4px;
      cursor: pointer;
      text-transform: uppercase;
      transition: all .2s;
      border: 1px solid;
    }
    .btn-ghost {
      background: transparent;
      border-color: rgba(255,34,34,0.4);
      color: var(--red);
    }
    .btn-ghost:hover {
      background: rgba(255,34,34,0.1);
      border-color: var(--red);
      box-shadow: 0 0 20px rgba(255,34,34,0.3);
    }
    .btn-solid {
      background: var(--red);
      border-color: var(--red);
      color: #000;
      font-weight: bold;
    }
    .btn-solid:hover {
      background: #ff5533;
      border-color: #ff5533;
      box-shadow: 0 0 25px rgba(255,34,34,0.5);
    }

    /* Fake IP log */
    .ip-log {
      position: fixed;
      bottom: 3rem;
      right: 1.5rem;
      font-size: .6rem;
      color: rgba(255,34,34,0.35);
      text-align: right;
      z-index: 10;
      line-height: 1.8;
      animation: reveal .3s 3.2s both;
    }

    /* Footer */
    footer {
      position: fixed;
      bottom: .8rem;
      left: 50%;
      transform: translateX(-50%);
      z-index: 10;
      font-size: .6rem;
      color: rgba(255,255,255,0.12);
      letter-spacing: .12em;
    }
    footer a {
      color: rgba(255,34,34,0.4);
      text-decoration: none;
      transition: color .2s;
    }
    footer a:hover { color: var(--red); }

    /* Corner decorations */
    .corner {
      position: fixed;
      width: 30px; height: 30px;
      z-index: 10;
      opacity: .35;
    }
    .corner.tl { top: 1.2rem; left: 1.2rem; border-top: 1px solid var(--red); border-left: 1px solid var(--red); }
    .corner.tr { top: 1.2rem; right: 1.2rem; border-top: 1px solid var(--red); border-right: 1px solid var(--red); }
    .corner.bl { bottom: 1.2rem; left: 1.2rem; border-bottom: 1px solid var(--red); border-left: 1px solid var(--red); }
    .corner.br { bottom: 1.2rem; right: 1.2rem; border-bottom: 1px solid var(--red); border-right: 1px solid var(--red); }
  </style>
</head>
<body>

<div id="cursor"></div>
<div id="cursor-dot"></div>
<div id="grid"></div>
<div id="glitch-overlay"></div>

<div class="corner tl"></div>
<div class="corner tr"></div>
<div class="corner bl"></div>
<div class="corner br"></div>

<main>
  <div class="warning-ring">
    <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="50" cy="50" r="46" stroke="#ff2222" stroke-width="1.5" stroke-dasharray="6 4"/>
      <path d="M50 28L50 57" stroke="#ff2222" stroke-width="4" stroke-linecap="round"/>
      <circle cx="50" cy="68" r="3" fill="#ff2222"/>
      <path d="M20 78 L50 22 L80 78 Z" stroke="#ff2222" stroke-width="1.5" fill="none" stroke-linejoin="round"/>
    </svg>
  </div>

  <div class="code-badge">&#9608; SECURITY ALERT &mdash; CODE 403 &#9608;</div>

  <h1>STOP.</h1>
  <div class="sub-headline">YOU ARE NOT SUPPOSED TO BE HERE</div>

  <div class="terminal">
    <span class="log-line"><span>[SYS]</span> Intrusion detected &mdash; logging session...</span>
    <span class="log-line"><span>[NET]</span> Tracing IP address... <span id="fake-ip">...</span></span>
    <span class="log-line warn"><span>[WARN]</span> Unauthorized access attempt flagged</span>
    <span class="log-line"><span>[SYS]</span> Notifying system administrator</span>
    <span class="log-line ok"><span>[LOG]</span> Incident recorded &mdash; <span id="ts"></span></span>
    <span class="log-line"><span>[SEC]</span> This area is restricted. Leave now.</span>
  </div>

  <div class="actions">
    <button class="btn btn-ghost" onclick="window.history.back()">&#8592; Go Back</button>
    <button class="btn btn-solid" onclick="window.location.href='/'">Return to Safety</button>
  </div>
</main>

<div class="ip-log">
  VISITOR IP: <span id="vis-ip">RESOLVING...</span><br>
  SESSION: <span id="sess-id"></span><br>
  STATUS: FLAGGED
</div>

<footer>
  <a href="https://xalb.xyz" target="_blank" rel="noopener">xalb.xyz</a>
</footer>

<script>
  // Custom cursor
  const cur = document.getElementById('cursor');
  const dot = document.getElementById('cursor-dot');
  document.addEventListener('mousemove', e => {
    cur.style.left = e.clientX + 'px';
    cur.style.top  = e.clientY + 'px';
    dot.style.left = e.clientX + 'px';
    dot.style.top  = e.clientY + 'px';
  });

  // Fake IP
  function randIP() {
    return [
      Math.floor(Math.random()*220+10),
      Math.floor(Math.random()*255),
      Math.floor(Math.random()*255),
      Math.floor(Math.random()*255)
    ].join('.');
  }
  const fakeIP = randIP();
  setTimeout(() => {
    document.getElementById('fake-ip').textContent = fakeIP;
    document.getElementById('vis-ip').textContent  = fakeIP;
  }, 900);

  // Session ID
  document.getElementById('sess-id').textContent =
    Math.random().toString(36).substring(2,10).toUpperCase();

  // Timestamp
  document.getElementById('ts').textContent = new Date().toISOString();
</script>
</body>
</html>

