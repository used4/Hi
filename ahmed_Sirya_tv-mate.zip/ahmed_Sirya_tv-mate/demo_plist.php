<!-- index.php -->
<?php 
include ('includes/header.php');

$table_name = 'demoplay';
$page_name = 'demo_plist';
$data = ['name' => 'demo','dns' => 'http://demo.4kapps.com','uname' => 'normal','pass' => 'demo'];

$db->insertIfEmpty($table_name, $data);

$res = $db->select($table_name, '*', '', '');

if(isset($_POST['submit'])){
    unset($_POST['submit']);
    $updateData = $_POST;
    $db->update($table_name, $updateData, 'id = :id',[':id' => 1]);
    echo "<script>window.location.href='". $page_name.".php'</script>";
}


?>
<!-- Form Start -->
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-12">
            <div class="bg-secondary rounded h-100 p-4">
                <h2 class="mb-4">Demo Playlist</h6>
                    <form method="post">
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Playlist Name</label>
                            <input type="text" name="name" class="form-control" value="<?=$res[0]['name'] ?>"
                                placeholder="Playlist Name">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">DNS</label>
                            <input type="text" name="dns" class="form-control" value="<?=$res[0]['dns'] ?>"
                                placeholder="DNS" >
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Username</label>
                            <input type="text" name="uname" class="form-control" value="<?=$res[0]['uname'] ?>"
                                placeholder="Username">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Passowrd</label>
                            <input type="text" name="pass" class="form-control" value="<?=$res[0]['pass'] ?>"
                                placeholder="Passowrd" >
                        </div>
                        <button type="submit" name="submit" class="btn btn-primary">Update demo</button>
                    </form>
            </div>
        </div>
    </div>
</div>
<!-- Form End -->

<!-- Footer Start -->
<?php include ('includes/footer.php');?>
<!-- Footer End -->
</body>

</html>