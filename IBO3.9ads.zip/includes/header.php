<?php
ini_set('display_errors', 1);
if(session_status() === PHP_SESSION_NONE) session_start();
include(__DIR__ . '/functions.php');

$log_check = $db->select('users', '*', 'id = :id', '', [':id' => 1]);
$loggedinuser = !empty($log_check) ? $log_check[0]['username'] : null;
if (empty($loggedinuser) && isset($_SESSION['name']) && $_SESSION['name'] === $loggedinuser) {
	header("Location: index.php");
	exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="author" content="REBRAND TW">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<link href="css/themes/darkly/bootstrap.css" rel="stylesheet" title="main">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.2.3/animate.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="css/simple-sidebar.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
</head>
<body>
<style>
/* Variables para la paleta de colores azul moderna */
:root {
    --blue-primary: #00B2CA;
    --blue-dark: #1d4e89;
    --blue-light: #51e2f5;
    --dark-bg: #0f1419;
    --medium-dark: #1a2332;
    --gray-text: #e1e8ed;
}

/* 1. Fondo y texto general */
body {
    background-color: var(--dark-bg);
    color: var(--gray-text);
    font-family: 'Roboto', sans-serif;
}

h1, h2, h3, h4, h5, h6 {
    color: var(--blue-light);
    font-weight: 500;
}

p, li, a {
    color: var(--gray-text);
}

/* 2. Sidebar */
#sidebar-wrapper {
    background: linear-gradient(180deg, var(--medium-dark) 0%, var(--dark-bg) 100%);
    border-right: 2px solid var(--blue-primary);
    box-shadow: 2px 0 15px rgba(0, 178, 202, 0.3);
}

.sidebar-heading {
    color: var(--blue-light) !important;
    background-color: transparent !important;
    font-weight: 700;
    font-size: 20px;
    letter-spacing: 1.5px;
    text-shadow: 0 0 10px rgba(81, 226, 245, 0.5);
    padding: 20px;
}

.list-group-item {
    color: var(--gray-text) !important;
    background-color: transparent !important;
    border-color: rgba(0, 178, 202, 0.2) !important;
    transition: all 0.3s ease;
    font-weight: 400;
}

.list-group-item:hover {
    color: #fff !important;
    background: linear-gradient(90deg, var(--blue-primary) 0%, transparent 100%) !important;
    border-left: 3px solid var(--blue-light) !important;
    box-shadow: 0 0 15px rgba(0, 178, 202, 0.4);
}

.list-grup-item, .list-grup-item a {
    color: var(--gray-text) !important;
    text-decoration: none;
    font-size: 0.85em;
    font-weight: 300;
}

/* 3. Navbar */
.navbar {
    background: linear-gradient(90deg, var(--medium-dark) 0%, var(--dark-bg) 100%);
    border-bottom: 2px solid var(--blue-primary);
    box-shadow: 0 2px 15px rgba(0, 178, 202, 0.3);
}

.navbar .navbar-brand, .navbar .nav-link {
    color: var(--blue-light);
    font-weight: 500;
}

.navbar .nav-link:hover {
    color: #fff;
    text-shadow: 0 0 10px rgba(81, 226, 245, 0.6);
}

/* 4. Botones */
.btn-primary, #menu-toggle {
    background: linear-gradient(135deg, var(--blue-primary) 0%, var(--blue-dark) 100%) !important;
    border: none !important;
    color: #fff !important;
    box-shadow: 0 0 15px rgba(0, 178, 202, 0.5);
    transition: all 0.3s ease;
    font-weight: 600;
    border-radius: 6px;
}

.btn-primary:hover, #menu-toggle:hover {
    background: linear-gradient(135deg, var(--blue-light) 0%, var(--blue-primary) 100%) !important;
    box-shadow: 0 0 20px rgba(81, 226, 245, 0.7);
    transform: translateY(-2px);
}

.btn-danger {
    background: linear-gradient(135deg, #dc3545 0%, #a02030 100%) !important;
    border: none !important;
    color: #fff !important;
    box-shadow: 0 0 15px rgba(220, 53, 69, 0.5);
    font-weight: 600;
    border-radius: 6px;
    transition: all 0.3s ease;
}

.btn-danger:hover {
    background: linear-gradient(135deg, #ff4757 0%, #dc3545 100%) !important;
    box-shadow: 0 0 20px rgba(220, 53, 69, 0.7);
    transform: translateY(-2px);
}

/* 5. Estilos de partículas (si se usa particles.js) */
#particles-js{
    background: none !important;
}
.particles-js-canvas-el {
    position: fixed;
    z-index: -1;
}

/* 6. Alertas (pop-up) */
#pageMessages {
    left: 50%;
    transform: translateX(-50%);
    position: fixed;
    text-align: center;
    top: 5px;
    width: 60%;
    z-index: 9999;
    border-radius: 8px;
}

.alert-primary, .alert-secondary {
    background-color: rgba(26, 35, 50, 0.95) !important;
    border: 2px solid var(--blue-primary) !important;
    color: var(--gray-text) !important;
    border-radius: 8px;
    box-shadow: 0 0 15px rgba(0, 178, 202, 0.4);
}

.alert-primary .close, .alert-secondary .close {
    color: var(--blue-light) !important;
}

.alert .fa {
    color: var(--blue-light) !important;
}

/* El resto de estilos para tarjetas, formularios, etc. */
.card {
    background: linear-gradient(135deg, var(--medium-dark) 0%, var(--dark-bg) 100%);
    border: 2px solid var(--blue-primary);
    color: var(--gray-text);
    border-radius: 10px;
    box-shadow: 0 4px 20px rgba(0, 178, 202, 0.3);
    transition: all 0.3s ease;
}

.card:hover {
    box-shadow: 0 6px 25px rgba(0, 178, 202, 0.5);
}

.card-header {
    background: linear-gradient(135deg, var(--blue-primary) 0%, var(--blue-dark) 100%);
    border-bottom: 2px solid var(--blue-light);
    color: #fff;
    font-weight: 600;
    border-radius: 8px 8px 0 0 !important;
}

.card-body {
    color: var(--gray-text);
}

.form-control {
    background-color: rgba(255, 255, 255, 0.08);
    border: 2px solid var(--blue-primary);
    color: #fff;
    font-size: 15px;
    border-radius: 6px;
    transition: all 0.3s ease;
}

.form-control::placeholder {
    color: #a8c5d1;
    font-weight: 300;
}

.form-control:focus {
    background-color: rgba(255, 255, 255, 0.12);
    border: 2px solid var(--blue-light);
    box-shadow: 0 0 15px rgba(81, 226, 245, 0.5);
    color: #fff;
    outline: none;
}

.table {
    color: var(--gray-text);
}

.table th {
    background: linear-gradient(135deg, var(--blue-primary) 0%, var(--blue-dark) 100%);
    color: #fff;
    border-color: var(--blue-light);
    font-weight: 600;
}

.table td {
    background-color: rgba(15, 20, 25, 0.6);
    color: var(--gray-text);
    border-color: rgba(0, 178, 202, 0.2);
}

.table-hover tbody tr:hover {
    background-color: rgba(0, 178, 202, 0.15);
    box-shadow: 0 0 10px rgba(0, 178, 202, 0.3);
}

.modal-content {
    background: linear-gradient(135deg, var(--medium-dark) 0%, var(--dark-bg) 100%);
    border: 2px solid var(--blue-primary);
    color: var(--gray-text);
    border-radius: 10px;
    box-shadow: 0 8px 30px rgba(0, 178, 202, 0.4);
}

.modal-header, .modal-footer {
    background-color: transparent;
    color: var(--gray-text);
    border-color: rgba(0, 178, 202, 0.3);
}

.modal-header .close {
    color: var(--blue-light);
    text-shadow: 0 0 10px rgba(81, 226, 245, 0.5);
}

.modal-title {
    color: var(--blue-light);
    font-weight: 600;
}

.modal-footer .btn {
    background: linear-gradient(135deg, var(--blue-primary) 0%, var(--blue-dark) 100%);
    border: none;
    color: #fff;
    font-weight: 600;
}

.modal-footer .btn:hover {
    background: linear-gradient(135deg, var(--blue-light) 0%, var(--blue-primary) 100%);
    box-shadow: 0 0 15px rgba(81, 226, 245, 0.6);
}

/* Mejoras adicionales */
.badge-primary {
    background: linear-gradient(135deg, var(--blue-primary) 0%, var(--blue-dark) 100%);
    color: #fff;
}

.badge-secondary {
    background-color: var(--medium-dark);
    color: var(--gray-text);
    border: 1px solid var(--blue-primary);
}

/* Scrollbar personalizado */
::-webkit-scrollbar {
    width: 10px;
}

::-webkit-scrollbar-track {
    background: var(--dark-bg);
}

::-webkit-scrollbar-thumb {
    background: var(--blue-primary);
    border-radius: 5px;
}

::-webkit-scrollbar-thumb:hover {
    background: var(--blue-light);
}
</style>
<div class="d-flex" id="wrapper">
	<div class="" id="sidebar-wrapper">
	  <div class="sidebar-heading">IBO PRO 3.9 </div>
	  <span><a class="list-grup-item" href="https://tuapk.top/" target="_blank">&nbsp;&nbsp;&nbsp;&nbsp;© <?=date("Y")?> * IBO PRO 3.9 * </a> </span></center>
	  <div class="list-group list-group-flush">
		<a class="list-group-item list-group-item-action" href="dns.php">
		<i class="fa fa-cogs"></i>&nbsp;&nbsp; DNS Settings </a>
		 <a class="list-group-item list-group-item-action" href="ads.php">
          <i class="fa fa-image"></i>&nbsp;&nbsp; Adverts </a>
		<a class="list-group-item list-group-item-action" href="user.php">
		<i class="fa fa-user"></i>&nbsp;&nbsp; Update credentials </a>
	  </div>
	</div>
	<div id="page-content-wrapper">

	  <nav class="navbar navbar-expand-lg navbar-dark">

		<button class="btn btn-primary" id="menu-toggle"><img src="img/logo.png" width="25" height="25" class="d-flex justify-content-center text-allign centre" alt=""></button>
		
	  &nbsp;&nbsp;
		<div class="center" id="pageMessages"></div>
		<a href="logout.php" class="btn btn-danger ml-auto mr-1">Logout</a>
	  </nav>

	  <div class="container-fluid"><br>
