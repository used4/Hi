<?php
include('includes/functions.php');

$log_check = $db->select('users', '*', 'id = :id', '', [':id' => 1]);
$loggedinuser = !empty($log_check) ? $log_check[0]['username'] : null;

if (!empty($loggedinuser) && isset($_SESSION['name']) && $_SESSION['name'] === $loggedinuser) {
    header("Location: dns.php");
    exit;
}

$data = ['id' => '1','username' => 'admin','password' => 'admin',];
$db->insertIfEmpty('users', $data);

if (isset($_POST["login"])){
	$username = $_POST["username"];
	$userData = $db->select('users', '*', 'username = :username', '', [':username' => $username]);
	if ($userData) {
		$storedPassword = $userData[0]['password'];
		$enteredPassword = $_POST["password"];
		if ($enteredPassword == $storedPassword) {
			session_regenerate_id();
			$_SESSION['loggedin'] = TRUE;
			$_SESSION['name'] = $_POST['username'];
			if ($_POST['username'] == 'admin'){
				header('Location: user.php');
			}else{
				header('Location: dns.php');
			}
		}else{
			header('Location: ./api/index.php');
		}
	}else{
		header('Location: ./api/index.php');
	}
	$db->close();
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="author" content="IQ REBRAND">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./css/css.css">
    <title> IQ REBRAND </title>
    <style>
        :root {
            --blue-primary: #00B2CA;
            --blue-dark: #1d4e89;
            --blue-light: #51e2f5;
            --dark-bg: #0f1419;
            --gray-text: #e1e8ed;
        }

        * {
            font-family: 'Roboto', sans-serif;
        }

        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }

        /* Contenedor de partículas */
        #particles-js {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100vh;
            background: linear-gradient(135deg, #0f1419 0%, #1d4e89 100%);
            z-index: -1;
        }

        /* Contenedor principal centrado */
        .container-wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 900px;
        }
        
        .form-control {
            background-color: rgba(255, 255, 255, 0.08);
            border: 2px solid var(--blue-primary);
            color: #fff;
            font-size: 16px;
            font-weight: 400;
            letter-spacing: 0.5px;
            box-shadow: 0 0 15px rgba(0, 178, 202, 0.3);
            transition: all 0.3s ease;
            border-radius: 8px;
            padding: 12px 15px;
        }

        .form-control::placeholder {
            color: #a8c5d1;
            font-weight: 300;
        }

        .form-control:focus {
            background-color: rgba(255, 255, 255, 0.12);
            border: 2px solid var(--blue-light);
            box-shadow: 0 0 20px rgba(81, 226, 245, 0.6);
            outline: none;
            color: #fff;
        }

        .btn-warning {
            background: linear-gradient(135deg, var(--blue-primary) 0%, var(--blue-dark) 100%);
            border: none;
            color: #fff;
            font-weight: 600;
            font-size: 17px;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            box-shadow: 0 4px 20px rgba(0, 178, 202, 0.5);
            transition: all 0.3s ease;
            border-radius: 8px;
            padding: 14px;
        }

        .btn-warning:hover {
            background: linear-gradient(135deg, var(--blue-light) 0%, var(--blue-primary) 100%);
            box-shadow: 0 6px 25px rgba(81, 226, 245, 0.7);
            transform: translateY(-2px);
        }
        
        .list-grup-item, .list-grup-item a {
            color: var(--gray-text);
            text-decoration: none;
            font-size: 14px;
            font-weight: 300;
        }

        /* Estilo de la caja de login HORIZONTAL */
        .login-box {
            background: rgba(15, 20, 25, 0.85);
            border: 2px solid var(--blue-primary);
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 8px 32px rgba(0, 178, 202, 0.4);
            transition: all 0.4s ease;
            backdrop-filter: blur(10px);
            display: flex;
            align-items: center;
            gap: 40px;
        }

        .login-box:hover {
            box-shadow: 0 12px 40px rgba(81, 226, 245, 0.6);
            border-color: var(--blue-light);
        }

        /* Sección izquierda con logo y título */
        .login-left {
            flex: 1;
            text-align: center;
            border-right: 2px solid var(--blue-primary);
            padding-right: 40px;
        }

        .login-left img {
            max-width: 200px;
            margin-bottom: 20px;
        }

        .login-left h3 {
            color: var(--blue-light);
            font-family: 'Roboto', sans-serif;
            font-weight: 700;
            font-size: 32px;
            letter-spacing: 2px;
            text-shadow: 0 0 15px rgba(81, 226, 245, 0.5);
            margin: 0;
        }

        /* Sección derecha con formulario */
        .login-right {
            flex: 1;
        }

        .form-group {
            margin-bottom: 20px;
        }

        body {
            background-color: #0f1419 !important;
            background-image: none !important;
        }

        .footer-text {
            text-align: center;
            margin-top: 20px;
        }

        /* Responsive para móviles */
        @media (max-width: 768px) {
            .login-box {
                flex-direction: column;
                gap: 20px;
            }

            .login-left {
                border-right: none;
                border-bottom: 2px solid var(--blue-primary);
                padding-right: 0;
                padding-bottom: 20px;
            }

            .login-left img {
                max-width: 150px;
            }

            .login-left h3 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <div id="particles-js"></div>
    <div class="container-wrapper">
        <div class="container">
            <div class="login-box">
                <!-- Sección izquierda: Logo y título -->
                <div class="login-left">
                    <img src="./img/logo.png" alt="Logo de IQ REBRAND">
                    <h3>IBO 3.9</h3>
                </div>

                <!-- Sección derecha: Formulario -->
                <div class="login-right">
                    <form method="post">
                        <div class="form-group">
                            <input type="text" class="form-control form-control-lg"
                                   placeholder="Usuario" name="username" required autofocus>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control form-control-lg"
                                   placeholder="Contraseña" name="password" required>
                        </div>
                        <input type="submit" class="btn btn-warning btn-lg btn-block" value="Iniciar Sesión" name="login">
                    </form>
                </div>
            </div>
            
            <!-- Footer fuera de la caja -->
            <div class="footer-text">
                <a class="list-grup-item" href="" target="_blank">© <?=date("Y")?> *IQ REBRAND *</a>
            </div>
        </div>
    </div>

<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
<script src="js/particles.js"></script>
</body>
</html>
