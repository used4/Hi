<?php
include('includes/header.php');

// Diretório onde as imagens estão armazenadas
$target_dir = "uploads/";

// Verifica se o formulário foi enviado
if(isset($_POST['submit'])){
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

    // Verifica se o arquivo é uma imagem
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }

    // Verifica se o arquivo já existe
    if (file_exists($target_file)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
    }

    // Verifica o tamanho do arquivo
    if ($_FILES["fileToUpload"]["size"] > 500000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Permite certos formatos de arquivo
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" 
    && $imageFileType != "gif" ) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // Tenta fazer o upload do arquivo se não houve erros
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            echo "The file ". htmlspecialchars(basename($_FILES["fileToUpload"]["name"])). " has been uploaded.";
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
}

// Verifica se uma imagem foi solicitada para exclusão
if(isset($_GET['delete'])){
    $file_to_delete = $target_dir . basename($_GET['delete']);
    if(file_exists($file_to_delete)){
        unlink($file_to_delete);
        echo "The file ". htmlspecialchars(basename($_GET['delete'])). " has been deleted.";
    } else {
        echo "Sorry, the file does not exist.";
    }
}
?>

<div class="col-md-8 mx-auto">
    <div class="card-body">
        <div class="card bg-primary text-white">
            <div class="card-header card-header-warning">
                <center>
                    <h2><i class="icon icon-upload"></i> Upload Image</h2>
                </center>
            </div>
            
            <div class="card-body">
                <div class="col-12">
                    <h3>Select image to upload:</h3>
                </div>
                    <form action="upload.php" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label class="form-label" for="fileToUpload">Select Image:</label>
                            <input type="file" name="fileToUpload" id="fileToUpload" class="form-control">
                        </div>
                        <div class="form-group">
                            <center>
                                <button class="btn btn-info" type="submit" name="submit">
                                    <i class="icon icon-check"></i> Upload Image
                                </button>
                            </center>
                        </div>
                    </form>
            </div>
        </div>
    </div>
</div>

<div class="col-md-8 mx-auto">
    <div class="card-body">
        <div class="card bg-primary text-white">
            <div class="card-header card-header-warning">
                <center>
                    <h2><i class="icon icon-images"></i> Uploaded Images</h2>
                </center>
            </div>
            <div class="card-body">
                <div class="row">
                    <?php
                    // Verifica se o diretório existe e é legível
                    if(is_dir($target_dir) && is_readable($target_dir)){
                        $images = scandir($target_dir); // Lista os arquivos no diretório
                        foreach($images as $image){
                            if($image != '.' && $image != '..'){ // Ignora os diretórios "." e ".."
                                echo '<div class="col-md-4">';
                                echo '<div class="card bg-light text-dark">';
                                echo '<img src="'.$target_dir.$image.'" class="card-img-top" alt="'.$image.'">';
                                echo '<div class="card-body">';
                                echo '<h5 class="card-title">'.htmlspecialchars($image).'</h5>';
                                echo '<a href="upload.php?delete='.urlencode($image).'" class="btn btn-danger">Delete</a>';
                                echo '</div>';
                                echo '</div>';
                                echo '</div>';
                            }
                        }
                    } else {
                        echo "No images found.";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>
