<?php
// Directorio donde las imágenes están almacenadas
$imageDir = "../uploads/";

// Verifica si el directorio existe y es legible
if (is_dir($imageDir) && is_readable($imageDir)) {
    // Lista los archivos en el directorio
    $images = scandir($imageDir);

    // Filtra solo las imágenes (ignorando . y ..)
    $images = array_filter($images, function ($image) use ($imageDir) {
        $filePath = $imageDir . $image;
        return !is_dir($filePath) && in_array(strtolower(pathinfo($filePath, PATHINFO_EXTENSION)), ['jpg', 'jpeg', 'png', 'gif']);
    });

    if (!empty($images)) {
        // Creamos un arreglo de URLs para que JavaScript lo use
        $imageUrls = array_map(function($image) use ($imageDir) {
            return $imageDir . $image;
        }, array_values($images));

        // Convertimos el arreglo PHP a una cadena JSON que JavaScript puede entender
        $jsonUrls = json_encode($imageUrls);

        // Creamos la estructura HTML con los estilos y el script de JavaScript
        echo "<html>";
        echo "<head>";
        echo "<style>";
        echo "body {";
        echo "    margin: 0;";
        echo "    background-color: black;";
        echo "    width: 100%;";
        echo "    height: 100%;";
        echo "    overflow: hidden;";
        echo "}";
        echo "img {";
        echo "    width: 100%;";
        echo "    height: 100%;";
        echo "    object-fit: cover;"; // ¡Aquí está el cambio!
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        echo "    <img id='ad-image' src='" . $imageUrls[0] . "' alt='Anuncio'>";
        echo "    <script>";
        echo "        const imageUrls = " . $jsonUrls . ";";
        echo "        let currentIndex = 0;";
        echo "        const adImage = document.getElementById('ad-image');";
        echo "        function changeImage() {";
        echo "            currentIndex = (currentIndex + 1) % imageUrls.length;";
        echo "            adImage.src = imageUrls[currentIndex];";
        echo "        }";
        echo "        setInterval(changeImage, 5000);"; // Cambia la imagen cada 5000 milisegundos (5 segundos)
        echo "    </script>";
        echo "</body>";
        echo "</html>";
    } else {
        echo "No images found in the directory.";
    }
} else {
    echo "Image directory not found or not readable.";
}
?>
