<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cinema Screen Style</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: #1a1a1a;
            color: #ffffff;
            font-family: 'Courier New', Courier, monospace;
            height: 100vh;
            width: 100vw;
            overflow: hidden;
            background-image: 
                linear-gradient(45deg, #222 25%, transparent 25%),
                linear-gradient(-45deg, #222 25%, transparent 25%),
                linear-gradient(45deg, transparent 75%, #222 75%),
                linear-gradient(-45deg, transparent 75%, #222 75%);
            background-size: 20px 20px;
        }

        .theater {
            width: 100vw;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .screen {
            width: 100%;
            height: 100%;
            background: #000;
            border-radius: 10px;
            box-shadow: 0 0 50px rgba(255,255,255,0.1);
            position: relative;
            overflow: hidden;
            animation: flicker 2s infinite;
        }

        .screen::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 200%;
            height: 5px;
            background: linear-gradient(90deg, 
                transparent, rgba(255,255,255,0.2), transparent);
            animation: scanline 4s linear infinite;
        }

        @keyframes scanline {
            0% { transform: translateX(-50%); }
            100% { transform: translateX(50%); }
        }

        .screen-content {
            width: 100%;
            height: 100%;
            position: relative;
        }

        .backdrop {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .movie-info {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 4vh;
            background: linear-gradient(
                transparent,
                rgba(0,0,0,0.7) 20%,
                rgba(0,0,0,0.85) 50%,
                rgba(0,0,0,0.95) 100%
            );
            display: flex;
            align-items: flex-end;
            gap: 3vw;
        }

        .movie-logo {
            height: 20vh;
            max-width: 35vw;
            object-fit: contain;
            filter: drop-shadow(0 0 10px rgba(0,0,0,0.5))
                    drop-shadow(0 0 20px rgba(0,0,0,0.5));
        }

        .movie-details {
            flex: 1;
            text-shadow: 
                2px 2px 4px rgba(0,0,0,1),
                -2px -2px 4px rgba(0,0,0,1),
                -2px 2px 4px rgba(0,0,0,1),
                2px -2px 4px rgba(0,0,0,1),
                0 0 10px rgba(0,0,0,1);
            position: relative;
            z-index: 2;
            display: flex; /* Añadido para centrar el título verticalmente */
            align-items: center; /* Centra el título verticalmente */
        }
        
        .movie-details::before {
            content: '';
            position: absolute;
            top: -20px;
            left: -20px;
            right: -20px;
            bottom: -20px;
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(5px);
            z-index: -1;
            border-radius: 10px;
        }

        .movie-details h1 {
            font-size: 3vh;
            margin-bottom: 0; /* Eliminado el margen inferior */
            color: #ffffff;
            font-weight: bold;
            letter-spacing: 0.5px;
        }
        
        /* Se ha eliminado la clase .movie-details p ya que no se usa */

        @keyframes flicker {
            0% { opacity: 0.8; }
            50% { opacity: 1; }
            100% { opacity: 0.8; }
        }
    </style>
</head>
<body>
    <div class="theater">
        <div class="screen">
            <div class="screen-content">
                <img id="backdrop" class="backdrop">
                <div class="movie-info">
                    <img id="movieLogo" class="movie-logo">
                    <div class="movie-details">
                        <h1 id="movieTitle"></h1>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const apiKey = '1beb49c014c0240a70367cbea2f0559f';
        
        async function fetchMovieDetails(movieId) {
            try {
                const [details, images] = await Promise.all([
                    fetch(`https://api.themoviedb.org/3/movie/${movieId}?api_key=${apiKey}&append_to_response=images`)
                        .then(r => r.json()),
                    fetch(`https://api.themoviedb.org/3/movie/${movieId}/images?api_key=${apiKey}&include_image_language=en,null`)
                        .then(r => r.json())
                ]);
                
                const allBackdrops = [
                    ...(details.backdrop_path ? [details.backdrop_path] : []),
                    ...(images.backdrops?.map(img => img.file_path) || [])
                ];
                
                return {
                    ...details,
                    all_backdrops: [...new Set(allBackdrops)],
                    images: {
                        ...details.images,
                        logos: details.images.logos || images.logos || []
                    }
                };
            } catch (error) {
                console.error('Error fetching movie data:', error);
                return null;
            }
        }

        async function updateMovieDisplay(movieId) {
            const details = await fetchMovieDetails(movieId);
            if (!details) return;
            
            const backdrops = details.all_backdrops;
            const randomBackdrop = backdrops[Math.floor(Math.random() * backdrops.length)];
            if (randomBackdrop) {
                document.getElementById('backdrop').src = 
                    `https://image.tmdb.org/t/p/original${randomBackdrop}`;
            }
            
            const logo = details.images.logos?.find(logo => logo.iso_639_1 === 'en') ||
                         details.images.logos?.[0];
            
            const logoElement = document.getElementById('movieLogo');
            if (logo) {
                logoElement.src = `https://image.tmdb.org/t/p/w500${logo.file_path}`;
                logoElement.style.display = 'block';
            } else {
                logoElement.style.display = 'none';
            }
            
            document.getElementById('movieTitle').textContent = details.title;
        }

        async function initialize() {
            try {
                const response = await fetch(
                    `https://api.themoviedb.org/3/movie/popular?api_key=${apiKey}&language=en-US`
                );
                const data = await response.json();
                if (data.results.length > 0) {
                    updateMovieDisplay(data.results[0].id);
                }
            } catch (error) {
                console.error('Error initializing:', error);
            }
        }

        initialize();

        setInterval(async () => {
            try {
                const response = await fetch(
                    `https://api.themoviedb.org/3/movie/popular?api_key=${apiKey}&language=en-US`
                );
                const data = await response.json();
                if (data.results.length > 0) {
                    const randomIndex = Math.floor(Math.random() * data.results.length);
                    updateMovieDisplay(data.results[randomIndex].id);
                }
            } catch (error) {
                console.error('Error updating:', error);
            }
        }, 12000);
    </script>
</body>
</html>