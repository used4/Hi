<html>

<head>
    <meta name="viewport" content='width=device-width, initial-scale=1.0,text/html,charset=utf-8'>
    <style>
     body {
        margin: 0;
        /* Reset default margin */
    }
   
     iframe {
        display: block;
        background: transparent;
        border: none;
        height: 100vh;
        width: 100vw;
    }
    </style>
</head>

<body>
<?php
$url = "https://sport-tv-guide.live/widgetsingle/5ae7b9142f55?list=3&id=1time_zone=America%2FLima&sport=1&fc=63,102&time12=1&lng=3/";
?>

<iframe id="iframe" src="<?=$url?>" frameborder="0" scrolling="auto"></iframe>
</body>
</html>