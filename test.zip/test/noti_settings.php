<!-- index.php -->
<?php 
include ('includes/header.php');

$table_name = 'noti';
$page_name = 'noti_settings';
$data = ['tital' => 'IBO PLAYER doesnt sell playlists or subscriptions','content' => 'Disclaimer: IBO PLAYER is a general media player and it does not include any content. You have to provide you own content. IBO PLAYER is not responsible for the content you use in the app'];

$db->insertIfEmpty($table_name, $data);

$res = $db->select($table_name, '*', '', '');

if(isset($_POST['submit'])){
    unset($_POST['submit']);
    $updateData = $_POST;
    $db->update($table_name, $updateData, 'id = :id',[':id' => 1]);
    echo "<script>window.location.href='". $page_name.".php'</script>";
}


?>
<!-- Form Start -->
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-12">
            <div class="bg-secondary rounded h-100 p-4">
                <h2 class="mb-4">Notification</h6>
                    <form method="post">
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Tital</label>
                            <input type="text" name="tital" class="form-control" value="<?=$res[0]['tital'] ?>"
                                placeholder="Password">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Content</label>
                            <input type="text" name="content" class="form-control" value="<?=$res[0]['content'] ?>"
                                placeholder="Password" >
                        </div>
                        <button type="submit" name="submit" class="btn btn-primary">Update Notification</button>
                    </form>
            </div>
        </div>
    </div>
</div>
<!-- Form End -->

<!-- Footer Start -->
<?php include ('includes/footer.php');?>
<!-- Footer End -->
</body>

</html>