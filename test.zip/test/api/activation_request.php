<?php
include(__DIR__ . '/../includes/functions.php'); 

$getmac = isset($_GET['mac']) ? $_GET['mac'] : '';
$message = (!empty($_GET['msg'])) ? $_GET['msg'] : 'No comments';


function getCurrentDateTimeAuto() {
    $timezone = @date_default_timezone_get();
    if (!$timezone) {
        $timezone = 'UTC';
    }
    date_default_timezone_set($timezone);
    return date('Y-m-d H:i:s');
}


function insertreqast($macaddress , $message, $Curruntdate) {
    $db = new SQLite3('./.db.db');
    $stmt = $db->prepare("INSERT INTO actreq (mac, date, remark) VALUES (:mac, :date, :remark)");
    
    $stmt->bindValue(':mac', $macaddress, SQLITE3_TEXT);
    $stmt->bindValue(':date', $Curruntdate, SQLITE3_TEXT);
    $stmt->bindValue(':remark', $message, SQLITE3_TEXT);

    $result = $stmt->execute();
    
    if(!empty($macaddress)){
        if ($result) {
            return out(1);
        } else {
            return out(2);
        }
    }else{
       return out(2); 
    }
}


function out($status){
    $success = [
     'status' => 'success',
     'message' => "Successfully Send Request"
     ];
     
    $error = [
     'status' => 'error',
     'message' => 'There was a problem. Please try again later.'
     ]; 
     
     if($status == 1){
         return json_encode($success);
     }else{
         return json_encode($error);
     }
}


echo insertreqast($getmac,$message,getCurrentDateTimeAuto());