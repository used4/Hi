<?php
include(__DIR__ . '/../includes/functions.php');
$res = $db->select('dns', '*', '', '');
$rowsJson = array();

$default_record['rtxname'] = 'Select server';
$default_record['rtxurl'] = '';
$default_record['movies_latest'] = '';
$default_record['series_latest'] = '';
$default_record['tab1'] = '';
$default_record['tab2'] = '';
$default_record['tab3'] = '';
$default_record['tab4'] = '';
$default_record['tab5'] = '';
$default_record['tab6'] = '';
array_push($rowsJson, $default_record);

foreach ($res as $row) {
    $row_array['rtxname'] = $row['title']; 
    $row_array['rtxurl'] = $row['url']; 
	$row_array['movies_latest'] = $row['movies_latest']; 
    $row_array['series_latest'] = $row['series_latest']; 
	$row_array['tab1'] = $row['tab1']; 
    $row_array['tab2'] = $row['tab2']; 
	$row_array['tab3'] = $row['tab3']; 
    $row_array['tab4'] = $row['tab4']; 
    $row_array['tab5'] = $row['tab5']; 
	$row_array['tab6'] = $row['tab6']; 
    array_push($rowsJson, $row_array); 
}
$final = json_encode($rowsJson, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
header('Content-type: application/json; charset=UTF-8');
$json = ["peterparker" => Encryption::run($final)]; 
echo $final;
?>
