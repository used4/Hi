<?php

// URL of the endpoint
$json_url = 'http://4matec.com/player_api.php?username=191311118468&password=756563427901';

// Initialize cURL session
$curl = curl_init();

// Set cURL options
curl_setopt($curl, CURLOPT_URL, $json_url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_VERBOSE, true);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true); // follow redirects if any
curl_setopt($curl, CURLOPT_HTTPHEADER, array(
    'accept: application/json, text/plain, */*',
        'Accept-Language: en-US,en;q=0.5',
        'x-application-type: WebClient',
        'x-client-version: 2.10.4',
        'Origin: https://www.googe.com',
        'user-agent: Mozilla/5.0 (Windows NT 10.0; rv:78.0) Gecko/20100101 Firefox/78.0',
    // Add any required cookies here if needed
));
curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 50); // timeout in seconds
curl_setopt($curl, CURLOPT_TIMEOUT, 30); // timeout in seconds

// Execute cURL session
$response = curl_exec($curl);

// Check for cURL errors
if(curl_errno($curl)) {
    echo 'Error: ' . curl_error($curl);
} else {
    // Display the response
    echo $response;
}

// Close cURL session
curl_close($curl);

?>
