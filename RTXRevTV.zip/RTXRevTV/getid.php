<?php 
include ('includes/header.php');
?>
		<div class="col-md-6 mx-auto ctmain-table">
			<div class="card-body">
				<div class="card ctcard">
					<div class="card-header">
						<center>
							<h2><i class="fa fa-id-badge"></i> Get Category ID</h2>
						</center>
					</div>
					<div class="card-body">
							<form id="linkForm">
								<div class="form-group ctinput">
									<div class="form-line">
										<label class="form-group form-float form-group-lg">Enter DNS</label>
										<input class="form-control" name="url1" id="url1"  type="text"/>
									</div>
								</div>
								<div class="form-group ctinput">
									<div class="form-line">
										<label class="form-group form-float form-group-lg">Enter the username of an account related to DNS</label>
										<input class="form-control" name="url2" id="url2"  type="text"/>
									</div>
								</div>
								<div class="form-group ctinput">
									<div class="form-line">
										<label class="form-group form-float form-group-lg">Enter the password of an account related to DNS</label>
										<input class="form-control" name="url3" id="url3"  type="text"/>
									</div>
								</div>
								<div class="form-group ctinput">
									<div class="form-line">
										<label class="form-group form-float form-group-lg">Select the required ID type</label>
										<select id="url4">
        									<option value="">Select the required ID type</option>
        									<option value="&action=get_vod_categories">GET MOVES CATEGORIES ID</option>
        									<option value="&action=get_series_categories">GET SERIES CATEGORIES ID</option>
    									</select><br>
									</div>
								</div>
								<hr>
								<div class="form-group ctinput">
									<center>
                						 <input class="btn btn-info" type="submit" value="Go">
									</center>
								</div>
							</form>	 
						</div>
					</div>
				</div>
		</div>
		<script>
		document.getElementById("linkForm").addEventListener("submit", function(event) {
			event.preventDefault();

			var url1 = document.getElementById("url1").value.trim();
			var url2 = document.getElementById("url2").value.trim();
			var url3 = document.getElementById("url3").value.trim();
			var url4 = document.getElementById("url4").value.trim();

			var fullURL1 = url1 + '/player_api.php?username=' + url2 +'&password='+ url3 + url4;

			if (fullURL1 !== "") {
				if (fullURL1 !== "") {
					openInNewTab(fullURL1);
				}
			} else {
				alert("Please enter at least one URL!");
			}
		});


		function openInNewTab(url) {
			if (isValidURL(url)) {
				window.open(url, '_blank');
			} else {
				alert("Invalid URL: " + url);
			}
		}

		function isValidURL(url) {
			var pattern = new RegExp('^(https?:\\/\\/)?'+ 
			'((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ 
			'((\\d{1,3}\\.){3}\\d{1,3}))'+ 
			'(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ 
			'(\\?[;&a-z\\d%_.~+=-]*)?'+ 
			'(\\#[-a-z\\d_]*)?$','i');
			return pattern.test(url);
		}
		</script>
<?php include ('includes/footer.php');?>

</body>
</html>