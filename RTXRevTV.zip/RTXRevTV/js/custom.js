VANTA.NET({
  el: "#net-canvas",
  mouseControls: true,
  touchControls: true,
  gyroControls: false,
  forceAnimate: true,
  minHeight: 700.00,
  minWidth: 200.00,
  scale: 1.00,
  scaleMobile: 1.00,
  backgroundColor: 0x1d1d1d,
  color: 0xf0833c
})