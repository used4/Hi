<?php
$jsondata = file_get_contents("./api/page.json");
$arrayData = json_decode($jsondata, true);
$json = $arrayData['app'];

if (isset($_POST['submit'])) {
    $replacementData = array(
        'app' => array(
            'selected_option' => $_POST["selected_option"]
        )
    );
    $replacementJson = json_encode($replacementData, JSON_PRETTY_PRINT);
    file_put_contents("./api/page.json", $replacementJson);
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

include ('includes/header.php');
?>
<style>
   .custom-image {
      width: 100%;
      max-width: 500px;
      height: auto;
   }
</style>
<main role="main" class="col-15 pt-4 px-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card bg-primary text-white">
                <div class="card-header card-header-warning">
                    <h2 class="text-center"><i class="fa fa-globe"></i> Widget Selection</h2>
                </div>
                <div class="card-body">
                    <div class="col-12">
                        <h3>Widgets Available</h3>
                    </div>
                    <form method="post">
                        <div class="form-group">
                            <label class="form-label" for="selected_option">Pick Your Widget</label>
                            <select class="form-control" id="select" name="selected_option">
                                <option value="image.php" <?= $json['selected_option'] == 'image.php' ? 'selected' : '' ?>>THEME 1</option>
                                <option value="tmdb.php" <?= $json['selected_option'] == 'tmdb.php' ? 'selected' : '' ?>>THEME 2</option>
                                <option value="ads.php" <?= $json['selected_option'] == 'ads.php' ? 'selected' : '' ?>>THEME 3</option>
                                <option value="fond.php" <?= $json['selected_option'] == 'fond.php' ? 'selected' : '' ?>>THEME 4</option>
                                <option value="adsv3.php" <?= $json['selected_option'] == 'adsv3.php' ? 'selected' : '' ?>>THEME 5</option>
                                <option value="adsv4.php" <?= $json['selected_option'] == 'adsv4.php' ? 'selected' : '' ?>>THEME 6</option>
                                <option value="adsv5.php" <?= $json['selected_option'] == 'adsv5.php' ? 'selected' : '' ?>>THEME 7</option>
                                <option value="adsv6.php" <?= $json['selected_option'] == 'adsv6.php' ? 'selected' : '' ?>>THEME 8</option>
                                <option value="adsv7.php" <?= $json['selected_option'] == 'adsv7.php' ? 'selected' : '' ?>>THEME 9</option>
                                <option value="adsv8.php" <?= $json['selected_option'] == 'adsv8.php' ? 'selected' : '' ?>>THEME 10</option>
                                <option value="adsv9.php" <?= $json['selected_option'] == 'adsv9.php' ? 'selected' : '' ?>>THEME 11</option>

                            </select>
                        </div>
                        <hr>
                        <div class="form-group text-center">
                            <button class="btn btn-info" name="submit" type="submit">
                                <i class="fa fa-check"></i> Submit
                            </button>
                        </div>
                        
                    </form>
                    <div class="grid-container" bis_skin_checked="1">
        <div class="grid-item" bis_skin_checked="1">
            <img src="./ads/adsv1.png" alt="Image 1">
            <div class="image-text" bis_skin_checked="1">Theme 1 </div>
        </div>
        <div class="grid-item" bis_skin_checked="1">
            <img src="./ads/adsv2.png" alt="Image 2">
            <div class="image-text" bis_skin_checked="1">Theme 2</div>
        </div>
        <div class="grid-item" bis_skin_checked="1">
            <img src="./ads/adsv3.png" alt="Image 3">
            <div class="image-text" bis_skin_checked="1">Theme 3</div>
        </div>
        <div class="grid-item" bis_skin_checked="1">
            <img src="./ads/adsv4.png" alt="Image 1">
            <div class="image-text" bis_skin_checked="1">Theme 4</div>
        </div>
        <div class="grid-item" bis_skin_checked="1">
            <img src="./ads/adsv5.png" alt="Image 2">
            <div class="image-text" bis_skin_checked="1">Theme 5</div>
        </div>
        <div class="grid-item" bis_skin_checked="1">
            <img src="./ads/adsv6.gif" alt="Image 3">
            <div class="image-text" bis_skin_checked="1">Theme 6</div>
        </div>
        <div class="grid-item" bis_skin_checked="1">
            <img src="./ads/adsv7.gif" alt="Image 1">
            <div class="image-text" bis_skin_checked="1">Theme 7</div>
        </div>
        <div class="grid-item" bis_skin_checked="1">
            <img src="./ads/adsv8.gif" alt="Image 2">
            <div class="image-text" bis_skin_checked="1">Theme 8</div>
        </div>   
         <div class="grid-item" bis_skin_checked="1">
            <img src="./ads/adsv9.gif" alt="Image 3">
            <div class="image-text" bis_skin_checked="1">Theme 9</div>
        </div>          
         <div class="grid-item" bis_skin_checked="1">
            <img src="./ads/adsv10.gif" alt="Image 1">
            <div class="image-text" bis_skin_checked="1">Theme 10</div>
        </div>
        <div class="grid-item" bis_skin_checked="1">
            <img src="./ads/adsv11.gif" alt="Image 2">
            <div class="image-text" bis_skin_checked="1">Theme 11</div>
        </div>   
         
         
    </div>
                </div>
      </div>
        </div>
    </div>
</main>
<style>
        .grid-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px; /* Adjust the gap between images */
            padding: 10px;
        }
        .grid-item {
            text-align: center;
        }
        .grid-item img {
            max-width: 100%;
            height: auto;
        }
        .image-text {
            margin-top: 5px;
            font-size: 16px;
            color: #fff;
        }
    </style>
<?php 
include('includes/footer.php');

// Verifica si boxbr.php existe antes de requerirlo
$boxbrPath = __DIR__ . '/includes/boxbr.php';
if (file_exists($boxbrPath)) {
    require $boxbrPath;
}
?>

</body>
</html>