<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>División en 2 Iframes</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    html, body {
      height: 100%;
      overflow: hidden;
      font-family: Arial, sans-serif;
      background: linear-gradient(to top, rgba(0, 0, 0, 1), transparent);
    }

    .contenedor {
      display: flex;
      height: 100vh;
      width: 100vw;
    }

    .iframe-derecho,
    .iframe-izquierdo {
      border: none;
      height: 100%;
    }

    .iframe-derecho {
      flex: 3;
    }

    .iframe-izquierdo {
      flex: 1;
      background: transparent; /* por si el navegador lo permite */
    }

    iframe {
      width: 100%;
      height: 100%;
      background: transparent;
    }
  </style>
</head>
<body>

  <div class="contenedor">
    <!-- Iframe izquierdo: contenido con fondo transparente -->
    <iframe class="iframe-izquierdo" src="ad.php" allowtransparency="true"></iframe>

    <!-- Iframe derecho: slider u otro contenido -->
    <iframe class="iframe-derecho" src="pe.php"></iframe>
  </div>

</body>
</html>
