<!-- index.php -->
<?php 
include ('includes/header.php');

$table_name = 'devop';
$page_name = 'dev_option';
$data = ['maxpg' => '8'];

$db->insertIfEmpty($table_name, $data);

$res = $db->select($table_name, '*', '', '');

if(isset($_POST['submit'])){
    unset($_POST['submit']);
    $updateData = $_POST;
    $db->update($table_name, $updateData, 'id = :id',[':id' => 1]);
    echo "<script>window.location.href='". $page_name.".php'</script>";
}


?>
<!-- Form Start -->
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-12">
            <div class="bg-secondary rounded h-100 p-4">
                <h2 class="mb-4">Panel Settings</h6>
                    <form method="post">
                        
                        <label for="exampleInputEmail1" class="form-label">User Results per page</label>
                        <select class="form-select mb-3" id="maxpg" name="maxpg">
                            <option value="2" <?=$res[0]['maxpg']=='2'?'selected':'' ?>>2 User's</option>
							<option value="5" <?=$res[0]['maxpg']=='5'?'selected':'' ?>>5 User's</option>
							<option value="8" <?=$res[0]['maxpg']=='8'?'selected':'' ?>>8 User's</option>
							<option value="10" <?=$res[0]['maxpg']=='10'?'selected':'' ?>>10 User's</option>
							<option value="15" <?=$res[0]['maxpg']=='15'?'selected':'' ?>>15 User's</option>
							<option value="20" <?=$res[0]['maxpg']=='20'?'selected':'' ?>>20 User's</option>
							<option value="25" <?=$res[0]['maxpg']=='25'?'selected':'' ?>>25 User's</option>
							<option value="30" <?=$res[0]['maxpg']=='30'?'selected':'' ?>>30 User's</option>
							<option value="40" <?=$res[0]['maxpg']=='40'?'selected':'' ?>>40 User's</option>
							<option value="50" <?=$res[0]['maxpg']=='50'?'selected':'' ?>>50 User's</option>
                        </select>
                        
                        
                        <button type="submit" name="submit" class="btn btn-primary">Update Panel Settingss</button>
                    </form>
            </div>
        </div>
    </div>
</div>
<!-- Form End -->

<!-- Footer Start -->
<?php include ('includes/footer.php');?>
<!-- Footer End -->
</body>

</html>