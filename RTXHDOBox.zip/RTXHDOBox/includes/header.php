<?php
ini_set('display_errors', 0);
include(__DIR__ . '/functions.php');
include(__DIR__ . '/json_utils.php');

$superusername = getmodsbyid('1') ?? 'superadmin';
$superpassword = getmodsbyid('2') ?? 'superadmin';
$weblink = getmodsbyid('3') ?? 'https://t.me/RTXshowcase';
$brandname = getmodsbyid('4') ?? 'RTX Rebrands';

$icon32x32 = getmodsbyid('8') ?? 'img/ficon/favicon-32x32.png';
$icon16x16 = getmodsbyid('9') ?? 'img/ficon/favicon-16x16.png';
$iconaplle = getmodsbyid('10') ?? 'img/ficon/apple-touch-icon.png';
$iconmain = getmodsbyid('11') ?? 'img/ficon/site.webmanifest';

if (session_status() === PHP_SESSION_NONE) {
	session_start();
}

$log_check = $db->select('user', '*', 'id = :id', '', [':id' => 1]);
$loggedinuser = !empty($log_check) ? $log_check[0]['username'] : null;

if (!isset($_SESSION['name']) == $loggedinuser) {
	header("location:"."index.php");
	exit();
}

if (isset($_REQUEST['logout'])) {
    session_destroy();
    setcookie("auth", "");
    header("Location: index.php");
    exit;
}

$time = $_SERVER['REQUEST_TIME'];

$timeout_duration = 900;
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
	session_unset();
	session_destroy();
	session_start();
}
$_SESSION['LAST_ACTIVITY'] = $time;

function sanitize($data) {
	$data = trim($data);
	$data = htmlspecialchars($data, ENT_QUOTES );
	$data = SQLite3::escapeString($data);
	return $data;
}


function adminisking(){
    global $superusername;
    if ($_SESSION['name'] == $superusername){
        return $_SESSION['name'] . ' 👑';
    }else{
        return $_SESSION['name'] . ' 🔥';
    }
}
?>
<!-- header.php -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?php echo $brandname; ?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <!--<link rel="apple-touch-icon" sizes="180x180" href="img/ficon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/ficon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/ficon/favicon-16x16.png">
    <link rel="manifest" href="img/ficon/site.webmanifest">-->
    
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo $iconaplle ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo $icon32x32 ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo $icon16x16 ?>">
    <link rel="manifest" href="<?php echo $iconmain ?>">

    
    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link
        href="https://fonts.googleapis.com/css2?family=Limelight&family=Monoton&family=Montserrat:ital,wght@0,100..900;1,100..900&family=Notable&display=swap"
        rel="stylesheet">


    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>
<style>
.version {
    font-size: 0.75rem;
    color: #6c757d;
    vertical-align: bottom;
    /* Ensures it aligns to the bottom of the parent inline element */
    position: relative;
    top: 6px;
    /* Fine-tune the vertical position if needed */
}

.bytx {
    font-size: 0.90rem;
    color: #EC2E2E;
    vertical-align: middle;
}
</style>

<body>
    <div class="container-fluid position-relative d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner"
            class="show bg-dark position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

        <!-- Sidebar Start -->
        <div class="sidebar pe-4 pb-3">
            <nav class="navbar bg-secondary navbar-dark">
                <a href="index.php" class="navbar-brand mx-4 mb-2">
                    <div class="d-flex flex-column">
                        <div class="d-flex align-items-center">
                            <h3 class="text-primary mb-0"><i class="fa fa-video-camera"></i> HDO Box</h3>
                            <span class="version ms-2">V 2.1.3</span>
                        </div>
                        <span class="bytx mt-0 mb-0">S E T T I N G S</span </div>
                </a>

                <!--<div class="d-flex align-items-center ms-4 mb-4">
                    <div class="position-relative">
                        <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                        <div class="bg-success rounded-circle border border-2 border-white position-absolute end-0 bottom-0 p-1"></div>
                    </div>
                </div>-->
                
                <div class="navbar-nav w-100">
                    <?php if ($_SESSION['name'] == $superusername || $_SESSION['passwordxyz'] == $superpassword){?>
                <a href="admin.php"
                        class="nav-item nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'admin.php' ? 'active' : ''; ?>"><i
                            class="fa fa-globe me-2"></i>👑 Super Admin</a>
                <?php }?>
                    <a href="main.php"
                        class="nav-item nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'main.php' ? 'active' : ''; ?>"><i
                            class="fa fa-globe me-2"></i>DNS Settings</a>
                            
                    <a href="panel_user.php"
                        class="nav-item nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'panel_user.php' ? 'active' : ''; ?>"><i
                            class="fa fa-user me-2"></i>Panel Users</a>        
                            
                            
                            
                    <a href="dev_option.php"
                        class="nav-item nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'dev_option.php' ? 'active' : ''; ?>"><i
                            class="fa fa-sliders me-2"></i>Panel Settings</a>
       
                    <a href="user.php"
                        class="nav-item nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'user.php' ? 'active' : ''; ?>"><i
                            class="fa fa-user me-2"></i>Credentials </a>
                </div>
            </nav>
        </div>
        <!-- Sidebar End -->

        <!-- Content Start -->
        <div class="content">

            <!-- Navbar Start -->
            <nav class="navbar navbar-expand bg-secondary navbar-dark sticky-top px-4 py-0">
                <a href="index.php" class="navbar-brand d-flex d-lg-none me-4">
                    <h2 class="text-primary mb-0"><i class="fa fa-video-camera"></i></h2>
                </a>
                <a href="#" class="sidebar-toggler flex-shrink-0">
                    <i class="fa fa-bars"></i>
                </a>
                <div class="navbar-nav align-items-center ms-auto">
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <img class="rounded-circle me-lg-2" src="img/rtx_bg.png" alt=""
                                style="width: 40px; height: 40px;">
                            <span class="d-none d-lg-inline-flex"><?php echo adminisking(); ?></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-secondary border-0 rounded-0 rounded-bottom m-0">
                            <a href="<?php echo $weblink; ?>" class="dropdown-item"><?php echo $brandname; ?></a>
                            <a href="<?=basename($_SERVER["SCRIPT_NAME"]).'?logout'?>" class="dropdown-item">Log Out</a>
                        </div>
                    </div>
                </div>
            </nav>
            <!-- Navbar End -->