<?php


$tables = [
	"user" => [
		"id" => "INTEGER PRIMARY KEY",
		"username" => "TEXT NOT NULL",
		"password" => "TEXT NOT NULL",
	],
	"int" => [
		"id" => "INTEGER PRIMARY KEY",
		"intro" => "TEXT NOT NULL",
	],
	"lon" => [
		"id" => "INTEGER PRIMARY KEY",
		"login" => "TEXT NOT NULL",
	],
	"name" => [
		"id" => "INTEGER PRIMARY KEY",
		"fname" => "TEXT NOT NULL",
		"parto" => "TEXT NOT NULL",
		"partt" => "TEXT NOT NULL",
	],
	"themes" => [
		"id" => "INTEGER PRIMARY KEY",
		"themeid" => "TEXT NOT NULL",
	],
	"dns" => [
		"id" => "INTEGER PRIMARY KEY",
		"title" => "TEXT",
		"url" => "TEXT",
	],
	"sortm" => [
		"id" => "INTEGER PRIMARY KEY",
		"sort" => "TEXT NOT NULL",
	],
	"sort" => [
		"id" => "INTEGER PRIMARY KEY",
		"sort" => "TEXT NOT NULL",
	],
	"menualusers" => [
		"id" => "INTEGER PRIMARY KEY",
    	"title" => "TEXT",
		"username" => "TEXT",
		"password" => "TEXT",
		"expire_date" =>"TEXT",
		"quota" =>"TEXT",
		"rquota" =>"TEXT",
		"cdate" =>"TEXT",
		"udate" =>"TEXT",
		"blok" => "TEXT NOT NULL",
	],
	"devop" => [
		"id" => "INTEGER PRIMARY KEY",
    	"maxpg" => "TEXT",
    	
	],
	"derec" => [
		"id" => "INTEGER PRIMARY KEY",
		"df" => "TEXT",
    	"mac" => "TEXT",
    	"uname" => "TEXT",
    	"pass" => "TEXT",
    	
    	
	],
	
];

?>