$phpDir = "D:\src\php_local"
if (-Not (Test-Path "$phpDir\php.exe")) {
    New-Item -ItemType Directory -Force -Path $phpDir | Out-Null
    Write-Host "Downloading portable PHP to run control panel locally..."
    Invoke-WebRequest -Uri "https://windows.php.net/downloads/releases/archives/php-8.1.13-nts-Win32-vs16-x64.zip" -OutFile "$phpDir\php.zip"
    Write-Host "Extracting..."
    Expand-Archive -Path "$phpDir\php.zip" -DestinationPath $phpDir -Force
    Remove-Item "$phpDir\php.zip" -Force
}

Write-Host ""
Write-Host "=========================================="
Write-Host "Admin Panel Started Successfully! "
Write-Host "Open this URL in your browser:"
Write-Host "http://localhost:8000"
Write-Host "Press (Ctrl + C) to stop the server."
Write-Host "=========================================="
Write-Host ""

Start-Process "http://localhost:8000"
& "$phpDir\php.exe" -S localhost:8000
