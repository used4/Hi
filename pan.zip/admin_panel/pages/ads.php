<div class="row">
    <div class="col-lg-8 offset-lg-2">
        <div class="glass-card">
            <div class="card-header">
                <h3 class="card-title">إعدادات الإعلانات</h3>
            </div>
            <div class="card-body">
                <form id="adsForm" onsubmit="event.preventDefault(); saveAdsSettings();">
                    
                    <div class="form-group" style="display: flex; align-items: center; justify-content: space-between; background: var(--glass-bg); padding: 15px; border-radius: 12px; border: 1px solid var(--glass-border); margin-bottom: 20px;">
                        <div>
                            <label class="form-label" style="margin-bottom: 0; font-size: 16px;">تفعيل نظام الإعلانات</label>
                            <small style="display: block; color: var(--text-muted); margin-top: 5px;">تشغيل أو إيقاف ظهور الديالوج الإعلاني للمستخدمين</small>
                        </div>
                        <label class="switch">
                            <input type="checkbox" id="adEnabledToggle">
                            <span class="slider round"></span>
                        </label>
                    </div>

                    <div class="form-group">
                        <label class="form-label">نوع الإعلان</label>
                        <select id="adTypeSelect" class="form-control" onchange="toggleAdTypeOptions()">
                            <option value="text">إعلان نصي (رسالة ترويجية)</option>
                            <option value="image">إعلان صورة (بنر إعلاني)</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">عنوان الإعلان (اختياري)</label>
                        <input type="text" id="adTitleInput" class="form-control" placeholder="أدخل عنواناً بارزاً للإعلان...">
                    </div>

                    <div class="form-group">
                        <label class="form-label" id="adContentLabel">نص الإعلان (الرسالة)</label>
                        <textarea id="adContentInput" class="form-control" rows="4" placeholder="اكتب نص أو تفاصيل الإعلان هنا..."></textarea>
                        <input type="text" id="adImageUrlInput" class="form-control" placeholder="أدخل رابط الصورة (URL) هنا..." style="display: none; direction: ltr;">
                    </div>

                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label class="form-label">عنوان الزر الإعلاني</label>
                            <input type="text" id="adButtonText" class="form-control" placeholder="اضغط هنا، اشترك الآن... (اتركه فارغاً لإخفاء الزر)">
                        </div>
                        <div class="col-md-6 form-group">
                            <label class="form-label">رابط الزر (URL)</label>
                            <input type="text" id="adButtonLink" class="form-control" placeholder="https://..." style="direction: ltr;">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">أماكن ظهور الإعلان</label>
                        <small style="display: block; color: var(--text-muted); margin-bottom: 10px;">اختر الأقسام التي تريد للإعلان أن يظهر فيها</small>
                        
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px;">
                            <label style="display: flex; align-items: center; gap: 8px; background: var(--glass-bg); padding: 10px; border-radius: 8px; border: 1px solid var(--glass-border); cursor: pointer;">
                                <input type="checkbox" name="adPages" value="live"> 
                                <span><i class="fas fa-play-circle" style="color: var(--primary)"></i> البث المباشر</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 8px; background: var(--glass-bg); padding: 10px; border-radius: 8px; border: 1px solid var(--glass-border); cursor: pointer;">
                                <input type="checkbox" name="adPages" value="movies"> 
                                <span><i class="fas fa-video" style="color: var(--primary)"></i> الأفلام</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 8px; background: var(--glass-bg); padding: 10px; border-radius: 8px; border: 1px solid var(--glass-border); cursor: pointer;">
                                <input type="checkbox" name="adPages" value="series"> 
                                <span><i class="fas fa-film" style="color: var(--primary)"></i> المسلسلات</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 8px; background: var(--glass-bg); padding: 10px; border-radius: 8px; border: 1px solid var(--glass-border); cursor: pointer;">
                                <input type="checkbox" name="adPages" value="settings"> 
                                <span><i class="fas fa-cog" style="color: var(--primary)"></i> الإعدادات</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 8px; background: var(--glass-bg); padding: 10px; border-radius: 8px; border: 1px solid var(--glass-border); cursor: pointer;">
                                <input type="checkbox" name="adPages" value="login"> 
                                <span><i class="fas fa-sign-in-alt" style="color: var(--primary)"></i> صفحة تسجيل الدخول</span>
                            </label>
                        </div>
                    </div>

                    <div class="text-center mt-4" style="margin-top: 30px;">
                        <button type="submit" class="btn btn-primary btn-lg" id="saveAdsBtn" style="width: 100%; max-width: 300px;">
                            <i class="fas fa-save"></i> حفظ إعدادات الإعلان
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Helper to toggle between text and image inputs
function toggleAdTypeOptions() {
    const type = document.getElementById('adTypeSelect').value;
    const isImage = type === 'image';
    
    document.getElementById('adContentInput').style.display = isImage ? 'none' : 'block';
    document.getElementById('adImageUrlInput').style.display = isImage ? 'block' : 'none';
    
    document.getElementById('adContentLabel').textContent = isImage ? 'رابط صورة الإعلان (URL)' : 'نص الإعلان';
}
</script>
