<?php
// ═══════════════════════════════════════════════════════════════
//  ForaTV - Logout Handler
// ═══════════════════════════════════════════════════════════════

require_once 'config.php';

// Destroy the session completely
$_SESSION = [];
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}
session_destroy();

// Redirect to login page
header('Location: login.php');
exit;
