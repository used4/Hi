<?php 


$sp_api = $db->select('spapi', '*', 'id = :id', '', [':id' => 1]);

$mykey = !empty($sp_api[0]['apikey']) ? $sp_api[0]['apikey'] : '484354';

$api_key = $mykey;

?>
