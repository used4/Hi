<?php 
include ('includes/header.php');
$table_name = 'adssettings';
$page_name = 'ads_settings';
$data = ['adstype' => 'auto'];
$db->insertIfEmpty($table_name, $data);
$res = $db->select($table_name, '*', '', '');

if(isset($_POST['submit'])){
    unset($_POST['submit']);
    $updateData = $_POST;
    $db->update($table_name, $updateData, 'id = :id',[':id' => 1]);
    echo "<script>window.location.href='". $page_name.".php?status=1'</script>";
}

// Moved the function definition to before its usage
function curruntvaleu($res){
    $getvalue = $res[0]['adstype'];
    if($getvalue == 'auto'){
        return "Auto Ads";
    } else if ($getvalue == 'manual'){
        return "Manual Ads";
    } else{
        return "Auto Ads";
    }
}
?>

<div class="col-md-6 mx-auto ctmain-table">
    <div class="card-body">
        <div class="card text-white ctcard">
            <div class="card-header card-header-warning">
                <center>
                    <h2><i class="icon icon-bullhorn"></i> Ads Type</h2>
                </center>
            </div>
            
            <div class="card-body">
                <form method="post">
                    <div class="form-group ctinput">
                        <label class="form-label"> Current Ads Type :</label>
                        <label><?php echo curruntvaleu($res); ?></label>
                    </div>
                    <div class="form-group ctinput">
                        <label class="form-label">Choose Ads Type </label>
                        <select id="adstype" name="adstype">
                            <option value="auto">Auto Ads</option>
                            <option value="manual">Manual Ads</option>
                        </select>
                    </div>
                    <div class="form-group ctinputform-group">
                        <center>
                            <button class="btn btn-info" name="submit" type="submit">
                                <i class="icon icon-check"></i> Submit
                            </button>
                        </center>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include ('includes/footer.php');?>
