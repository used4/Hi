<?php 
include ('includes/header.php');
$table_name = 'theme';
$page_name = 'themes';
$data = ['theme_no' => 'theme_0'];
$db->insertIfEmpty($table_name, $data);
$res = $db->select($table_name, '*', '', '');

if(isset($_POST['submit'])){
	unset($_POST['submit']);
	$updateData = $_POST;
	$db->update($table_name, $updateData, 'id = :id',[':id' => 1]);
	echo "<script>window.location.href='". $page_name.".php?status=1'</script>";
}

function curruntvaleu($res){
    $getvalue = $res[0]['theme_no'];
    if($getvalue == 'theme_0'){
        return " Theme [1]";
    } else if ($getvalue == 'theme_1'){
        return " Theme [2]";
    } else if ($getvalue == 'theme_2'){
        return " Theme [3]";
    } else if ($getvalue == 'theme_3'){
        return " Theme [4]";
    } else if ($getvalue == 'theme_4'){
        return " Theme [5]";
    } else if ($getvalue == 'theme_5'){
        return " Theme [6]";
    } else if ($getvalue == 'theme_6'){
        return " Theme [7]";
    } else if ($getvalue == 'theme_7'){
        return " Theme [8]";
    } else if ($getvalue == 'theme_8'){
        return " Theme [9]";
    } else if ($getvalue == 'theme_9'){
        return " Theme [10]";
    } else if ($getvalue == 'theme_10'){
        return " Theme [11]";
    } else if ($getvalue == 'theme_11'){
        return " Theme [12]";
    } else if ($getvalue == 'theme_12'){
        return " Theme [13]";
    } else if ($getvalue == 'theme_13'){
        return " Theme [14]";
    }else if ($getvalue == 'theme_14'){
        return " Theme [15]";
    }else if ($getvalue == 'theme_15'){
        return " Theme [16]";
    }else if ($getvalue == 'theme_16'){
        return " Theme [17]";
    }else{
        return "Theme [1]]";
    }
}
?>

?>

        <div class="col-md-12 mx-auto ctmain-table">
            <div class="card-body">
                <div class="card text-white ctcard">
                    <div class="card-header card-header-warning">
                        <center>
                            <h2><i class="icon icon-bullhorn"></i> Notification</h2>
                        </center>
                    </div>
                    
           <div class="card-body">
                <form method="post">
                    <div class="form-group ctinput">
                        <label class="form-label"> Current Theme :</label>
                        <label><?php echo curruntvaleu($res); ?></label>
                    </div>
                    <div class="form-group ctinput">
                        <label class="form-label">Choose Theme </label>
                        <select id="theme_no" name="theme_no">
                            <option value="theme_0">Theme 1</option>
                            <option value="theme_1">Theme 2</option>
                            <option value="theme_2">Theme 3</option>
                            <option value="theme_3">Theme 4</option>
                            <option value="theme_4">Theme 5</option>
                            <option value="theme_5">Theme 6</option>
                        	<option value="theme_6">Theme 7</option>
                        	<option value="theme_7">Theme 8</option>
                        	<option value="theme_8">Theme 9</option>
                        	<option value="theme_9">Theme 10</option>
                        	<option value="theme_10">Theme 11</option>
                        	<option value="theme_11">Theme 12</option>
                        	<option value="theme_12">Theme 13</option>
                        	<option value="theme_13">Theme 14</option>
                        	<option value="theme_14">Theme 15</option>
                        	<option value="theme_15">Theme 16</option>
                        	<option value="theme_16">Theme 17</option>
                        </select>
                    </div>
                    <div class="form-group ctinputform-group">
                        <center>
                            <button class="btn btn-info" name="submit" type="submit">
                                <i class="icon icon-check"></i> Submit
                            </button>
                        </center>
                    </div>
                </form>
            </div>       


	<div class="grid-container">
        <div class="grid-item">
            <img src="./theme/thme_1_resized.png" alt="Image 1">
            <div class="image-text">Theme 1</div>
        </div>
        <div class="grid-item">
            <img src="./theme/thme_2_resized.png" alt="Image 2">
            <div class="image-text">Theme 2</div>
        </div>
        <div class="grid-item">
            <img src="./theme/thme_3_resized.png" alt="Image 3">
            <div class="image-text">Theme 3</div>
        </div>
        <div class="grid-item">
            <img src="./theme/thme_4_resized.png" alt="Image 1">
            <div class="image-text">Theme 4</div>
        </div>
        <div class="grid-item">
            <img src="./theme/thme_5_resized.png" alt="Image 2">
            <div class="image-text">Theme 5</div>
        </div>
        <div class="grid-item">
            <img src="./theme/thme_6_resized.png" alt="Image 3">
            <div class="image-text">Theme 6</div>
        </div>
        <div class="grid-item">
            <img src="./theme/thme_7.resized.png" alt="Image 1">
            <div class="image-text">Theme 7</div>
        </div>
        <div class="grid-item">
            <img src="./theme/thme_8.resized.png" alt="Image 2">
            <div class="image-text">Theme 8</div>
        </div>
        <div class="grid-item">
            <img src="./theme/thme_9.resized.png" alt="Image 3">
            <div class="image-text">Theme 9</div>
        </div>
        <div class="grid-item">
            <img src="./theme/thme_10.resized.png" alt="Image 1">
            <div class="image-text">Theme 10 [Manual ads only]</div>
        </div>
        <div class="grid-item">
            <img src="./theme/thme_11.resized.png" alt="Image 2">
            <div class="image-text">Theme 11 [Manual ads only]</div>
        </div>
        <div class="grid-item">
            <img src="./theme/thme_12.resized.png" alt="Image 3">
            <div class="image-text">Theme 12 [Manual ads only]</div>
        </div>     
        <div class="grid-item">
            <img src="./theme/thme_13.resized.png" alt="Image 1">
            <div class="image-text">Theme 13</div>
        </div>    
        <div class="grid-item">
            <img src="./theme/thme_14.resized.png" alt="Image 2">
            <div class="image-text">Theme 14</div>
        </div>  
        <div class="grid-item">
            <img src="./theme/thme_15.resized.png" alt="Image 3">
            <div class="image-text">Theme 15</div>
        </div>  
                        
        <div class="grid-item">
            <img src="./theme/thme_16.resized.png" alt="Image 1">
            <div class="image-text">Theme 16 [Frame ads only]</div>
        </div>    
        <div class="grid-item">
            <img src="./theme/thme_17.resized.png" alt="Image 2">
            <div class="image-text">Theme 17 [Frame ads only]</div>
        </div>                 
    </div>


                    </div>
                </div>
            </div>
        </div>
<style>
        .grid-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px; /* Adjust the gap between images */
            padding: 10px;
        }
        .grid-item {
            text-align: center;
        }
        .grid-item img {
            max-width: 100%;
            height: auto;
        }
        .image-text {
            margin-top: 5px;
            font-size: 16px;
            color: #fff;
        }
    </style>
<?php include ('includes/footer.php');?>