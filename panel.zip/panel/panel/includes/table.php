<?php


$tables = [
	"user" => [
		"id" => "INTEGER PRIMARY KEY",
		"username" => "TEXT NOT NULL",
		"password" => "TEXT NOT NULL",
	],
	"dns" => [
		"id" => "INTEGER PRIMARY KEY",
		"title" => "TEXT",
		"url" => "TEXT",
	],
	"ibo" => [
		"id" => "INTEGER PRIMARY KEY NOT NULL",
		"mac_address" => "TEXT",
		"username" => "TEXT",
    	"password" => "TEXT",
    	"protection" => "TEXT",
    	"url" => "TEXT",
		"title" => "TEXT",
	],
	"ibocode" => [
		"id" => "INTEGER PRIMARY KEY NOT NULL",
		"ac_code" => "TEXT",
		"username" => "TEXT",
    	"password" => "TEXT",
    	"status" => "TEXT",
    	"url" => "TEXT",
	],
	
    "sports" => [
		"id" => "INTEGER PRIMARY KEY",
		"header_n" => "TEXT",
		"border_c" => "TEXT",
        "background_c" => "TEXT",
		"text_c" => "TEXT",
        "days" => "TEXT",
		"api" => "TEXT",
	],
	"welcome" => [
		"id" => "INTEGER PRIMARY KEY",
		"message_one" => "TEXT",
		"message_two" => "TEXT",
	],
	"macl" => [
		"id" => "INTEGER PRIMARY KEY",
		"mac_length" => "TEXT",
	],
	"theme" => [
		"id" => "INTEGER PRIMARY KEY",
		"theme_no" => "TEXT",
	],
	"trial" => [
		"id" => "INTEGER PRIMARY KEY",
		"mac_address" => "TEXT",
    	"expire_date" => "TEXT",
	],
	"perant" => [
		"id" => "INTEGER PRIMARY KEY",
		"mac_address" => "TEXT",
    	"password" => "TEXT",
	],
	"adssettings" => [
		"id" => "INTEGER PRIMARY KEY",
		"adstype" => "TEXT",
	],
	"autolayout" => [
		"id" => "INTEGER PRIMARY KEY",
		"layout" => "TEXT",
	],
	"framelayout" => [
		"id" => "INTEGER PRIMARY KEY",
		"layout" => "TEXT",
	],
	"menuads" => [
		"id" => "INTEGER PRIMARY KEY",
    	"title" => "TEXT",
		"url" => "TEXT",
	],
	"appupdate" => [
		"id" => "INTEGER PRIMARY KEY",
    	"nversion" => "TEXT",
		"nurl" => "TEXT",
	],
	"licens" => [
		"id" => "INTEGER PRIMARY KEY",
    	"lkey" => "TEXT",
	],
	"leaguesx" => [
		"id" => "INTEGER PRIMARY KEY",
    	"league" => "TEXT",
    	"leagueId" => "TEXT",
    	
	],
	"leaguestable" => [
		"id" => "INTEGER PRIMARY KEY",
    	"league" => "TEXT",
    	"leagueId" => "TEXT",
    	
	],
	"demopls" => [
		"id" => "INTEGER PRIMARY KEY",
    	"mplname" => "TEXT",
    	"mdns" => "TEXT",
    	"muser" => "TEXT",
    	"mpass" => "TEXT",
    	
	],
	"logintheme" => [
		"id" => "INTEGER PRIMARY KEY",
    	"themelog" => "TEXT",
    	
	],
	"logintext" => [
		"id" => "INTEGER PRIMARY KEY",
    	"logintitial" => "TEXT",
    	"loginsubtitial" => "TEXT",
    	
	],

];

?>