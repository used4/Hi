<?php
include(__DIR__ . '/../includes/functions.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

const ALLOWED_CHARACTERS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";

function getDecodedString($str) {
    $encryptKeyPosition = getEncryptKeyPosition(substr($str, -2, 1));
    $encryptKeyPosition2 = getEncryptKeyPosition(substr($str, -1));
    $substring = substr($str, 0, -2);
    $decodedString = base64_decode(substr($substring, 0, $encryptKeyPosition) . substr($substring, $encryptKeyPosition + $encryptKeyPosition2));
    return trim(utf8_decode($decodedString));
}

function getEncryptKeyPosition($char) {
    return strpos(ALLOWED_CHARACTERS, $char);
}

function getEncodedString($str) {
    $encodedString = base64_encode(utf8_encode($str));
    $encryptKeyPosition = getEncryptKeyPosition(substr($encodedString, -2, 1));
    $encryptKeyPosition2 = getEncryptKeyPosition(substr($encodedString, -1));
    $substring = substr($encodedString, 0, $encryptKeyPosition) . substr($encodedString, $encryptKeyPosition + $encryptKeyPosition2);
    return $substring . substr(ALLOWED_CHARACTERS, $encryptKeyPosition, 1) . substr(ALLOWED_CHARACTERS, $encryptKeyPosition2, 1);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $post_data = file_get_contents('php://input');
    $json_data = json_decode($post_data, true);
    $decode_Data = isset($json_data['data']) ? $json_data['data'] : 'null';
    $json_data_first = getDecodedString($decode_Data);
    $json_data_decode = json_decode($json_data_first, true);

	$mac_address_get = isset($json_data_decode['mac_address']) ? $json_data_decode['mac_address'] : 'null';
    $playlist_id_get = isset($json_data_decode['playlist_id']) ? $json_data_decode['playlist_id'] : 'null';
	$pos = strpos($playlist_id_get, 'RTXREBRAND');
	$number = substr($playlist_id_get, $pos + strlen('RTXREBRAND'));



    global $db; 
    $ret = $db->select('ibo', '*', 'id = :id', '', [':id' => $number]);
	$dbPath = './.db.db';
    $dbkm = new SQLiteWrapper($dbPath);
	porgress($ret,$dbkm, $mac_address_get, $number);
    
}

function porgress($dbdata,$updatedb, $postMAC, $postID){

	if (empty($postID)){
    	error();
    }else{
    	$mac_address = strtolower($dbdata[0]['mac_address'] ?? null);
    	$db_id = strtolower($dbdata[0]['id'] ?? null);
    
    	if($mac_address == $postMAC || $db_id == $postID){
        	$updatedb->delete('ibo', 'id = :id',[':id' => $postID]);
        	sucsess();
        }else{
        	error();
        }
    	
    }
	
}



function error() {
    $response = ["status" => false, "message" => "system Error"];
    header('Content-type: application/json; charset=UTF-8');
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function sucsess() {
    $response = ["status" => true, "message" => "save and update data"];
    header('Content-type: application/json; charset=UTF-8');
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}



?>
