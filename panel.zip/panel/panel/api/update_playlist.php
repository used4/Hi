<?php
include(__DIR__ . '/../includes/functions.php');
error_reporting(E_ALL);
ini_set('display_errors', 0);

const ALLOWED_CHARACTERS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";

function getDecodedString($str) {
    $encryptKeyPosition = getEncryptKeyPosition(substr($str, -2, 1));
    $encryptKeyPosition2 = getEncryptKeyPosition(substr($str, -1));
    $substring = substr($str, 0, -2);
    $decodedString = base64_decode(substr($substring, 0, $encryptKeyPosition) . substr($substring, $encryptKeyPosition + $encryptKeyPosition2));
    return trim(utf8_decode($decodedString));
}

function getEncryptKeyPosition($char) {
    return strpos(ALLOWED_CHARACTERS, $char);
}

function getEncodedString($str) {
    $encodedString = base64_encode(utf8_encode($str));
    $encryptKeyPosition = getEncryptKeyPosition(substr($encodedString, -2, 1));
    $encryptKeyPosition2 = getEncryptKeyPosition(substr($encodedString, -1));
    $substring = substr($encodedString, 0, $encryptKeyPosition) . substr($encodedString, $encryptKeyPosition + $encryptKeyPosition2);
    return $substring . substr(ALLOWED_CHARACTERS, $encryptKeyPosition, 1) . substr(ALLOWED_CHARACTERS, $encryptKeyPosition2, 1);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $post_data = file_get_contents('php://input');
    $json_data = json_decode($post_data, true);
    $decode_Data = isset($json_data['data']) ? $json_data['data'] : 'null';
    $json_data_first = getDecodedString($decode_Data);
    $json_data_decode = json_decode($json_data_first, true);

	$mac_address_get = isset($json_data_decode['mac_address']) ? $json_data_decode['mac_address'] : 'null';
	$playlist_id_get = isset($json_data_decode['playlist_id']) ? $json_data_decode['playlist_id'] : 'null';
    $playlist_url_get = isset($json_data_decode['playlist_url']) ? $json_data_decode['playlist_url'] : 'null';

	$pos = strpos($playlist_id_get, 'RTXREBRAND');
	$number = substr($playlist_id_get, $pos + strlen('RTXREBRAND'));

	$url_components = parse_url($playlist_url_get);
	parse_str($url_components['query'], $params);
	$username_get = $params['username'];
	$password_get = $params['password'];



	global $db; 
    $ret = $db->select('ibo', '*', 'id = :id', '', [':id' => $number]);
	$dbPath = './.db.db';
    $dbkm = new SQLiteWrapper($dbPath);

	porgress($ret,$dbkm, $mac_address_get, $number , $username_get, $password_get);
	
	

	
    
}

function porgress($dbdata,$updatedb, $postMAC, $postID, $newuser , $newPass){

	if (empty($postID)){
    	error();
    }else{
    	$mac_address = strtolower($dbdata[0]['mac_address'] ?? null);
    	$db_id = strtolower($dbdata[0]['id'] ?? null);
    
    	if($mac_address == $postMAC || $db_id == $postID){
        	update($dbdata , $updatedb , $postID , $newuser , $newPass);
        }else{
        	error();
        }
    	
    }
	
}



function error() {
    $response = ["status" => false, "message" => "system Error"];
    header('Content-type: application/json; charset=UTF-8');
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function sucsess($dbdata , $newuser , $newpass) {
	$gid = $dbdata[0]['id'];
	$gname = $dbdata[0]['title'];
	$gurl = $dbdata[0]['url'];
	$gusername = $newuser;
    $gpassword = $newpass;
	$gprot = $dbdata[0]['protection'];


    $response = [
    "name" => $gname, 
    "id" => md5($gpassword).'RTXREBRAND' . $gid, 
    "url" =>  $gurl ."/get.php?username=".$gusername."&password=".$gpassword."&type=m3u_plus&output=ts", 
    "host" => $gurl,  
    "username" => $gusername, 
    "password" => $gpassword,  
    "is_protected" => $gprot,
    "created_at" => "2023-04-15 00:06:09", 
    "updated_at" => "2023-04-15 00:06:09"];

    header('Content-type: application/json; charset=UTF-8');
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
function update ($dbdata,$updatedb , $listid , $newuser , $newpass){
	$dataToUpdate = ['username' => $newuser , 'password' => $newpass];
    $whereCondition = "id = :id";
    $placeholders = [':id' => $listid];
    $updatedb->update('ibo', $dataToUpdate, $whereCondition, $placeholders);
	$updatedb->close();
	sucsess($dbdata, $newuser, $newpass);
}
?>
