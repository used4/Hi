<?php
include(__DIR__ . '/../includes/functions.php');
$mes = $db->select('autolayout', '*', 'id = :id', '', [':id' => 1]);
error_reporting(E_ALL);
ini_set('display_errors', 1);

$adslayout;

if (empty($mes[0]['layout'] ?? null) || empty($mes[0]['layout'] ?? null)){
	$adslayout = 'layout_0';
}else{
	$adslayout = $mes[0]['layout'];
}


switch ($adslayout) {
    case "layout_0":
    		header("Location: ./ads/autoads_0.php");
			exit();
        break;

	case "layout_1":
    		header("Location: ./ads/autoads_1.php");
			exit();
        break;

	case "layout_2":
    		header("Location: ./ads/autoads_2.php");
			exit();
        break;

	case "layout_3":
    		header("Location: ./ads/autoads_3.php");
			exit();
        break;

	case "layout_4":
    		header("Location: ./ads/autoads_4.php");
			exit();
        break;

	case "layout_5":
    		header("Location: ./ads/autoads_5.php");
			exit();
        break;

	case "layout_6":
    		header("Location: ./ads/autoads_6.php");
			exit();
        break;

	case "layout_7":
    		header("Location: ./ads/autoads_7.php");
			exit();
        break;

	case "layout_8":
    		header("Location: ./ads/autoads_8.php");
			exit();
        break;

	case "layout_9":
    		header("Location: ./ads/autoads_9.php");
			exit();
        break;

	case "layout_10":
    		header("Location: ./ads/autoads_10.php");
			exit();
        break;

	case "layout_11":
    		header("Location: ./ads/autoads_11.php");
			exit();
        break;

	case "layout_12":
    		header("Location: ./ads/autoads_12.php");
			exit();
        break;

	case "layout_13":
    		header("Location: ./ads/autoads_13.php");
			exit();
        break;

    default:
    		header("Location: ./ads/autoads_0.php");
			exit();
        break;
}

?>
