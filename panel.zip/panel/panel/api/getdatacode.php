<?php
include(__DIR__ . '/../includes/functions.php');

// جلب بيانات الكود من قاعدة MySQL
$ret = $db->select('ibocode', '*', 'ac_code = :ac_code', '', [':ac_code' => $_GET['accode']]);

// فتح قاعدة SQLite (لن نحتاج لتحديث الحالة)
$dbPath = './.db.db';
$dbkm = new SQLiteWrapper($dbPath);

getkey($ret, $dbkm);

function getkey($dbdata, $updatedb){
    if (empty($_GET['accode'])){
        $response = [
            "status" => "unsuccess",
            "dns" => "Invalid activation code."
        ];
    } else {
        
        // إذا لم يتم العثور على الكود
        if (empty($dbdata) || !isset($dbdata[0])) {
            $response = [
                "status" => "unsuccess",
                "dns" => "Activation code not found."
            ];
        } else {

            // استخراج البيانات من السجل
            $username = $dbdata[0]['username'];
            $password = $dbdata[0]['password'];
            $url      = $dbdata[0]['url'];
            $code     = $dbdata[0]['ac_code'];

            // التحقق من أن الكود صحيح فقط
            if ($_GET['accode'] == $code){

                // *** تعديل مهم ***
                // السماح باستخدام الكود عدد غير محدود من الأجهزة
                // تم إلغاء التحقق من حالة USED
                // وتم إلغاء تحديث الحالة

                $response = [
                    "status" => "success",
                    "dns" => $url,
                    "username" => $username,
                    "password" => $password
                ];

            } else {
                $response = [
                    "status" => "unsuccess",
                    "dns" => "Invalid activation code."
                ];
            }
        }
    }

    // إخراج JSON
    header('Content-type: application/json; charset=UTF-8');
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

?>