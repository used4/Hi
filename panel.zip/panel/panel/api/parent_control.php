<?php
include(__DIR__ . '/../includes/functions.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

const ALLOWED_CHARACTERS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";

function getDecodedString($str) {
    $encryptKeyPosition = getEncryptKeyPosition(substr($str, -2, 1));
    $encryptKeyPosition2 = getEncryptKeyPosition(substr($str, -1));
    $substring = substr($str, 0, -2);
    $decodedString = base64_decode(substr($substring, 0, $encryptKeyPosition) . substr($substring, $encryptKeyPosition + $encryptKeyPosition2));
    return trim(utf8_decode($decodedString));
}

function getEncryptKeyPosition($char) {
    return strpos(ALLOWED_CHARACTERS, $char);
}

function getEncodedString($str) {
    $encodedString = base64_encode(utf8_encode($str));
    $encryptKeyPosition = getEncryptKeyPosition(substr($encodedString, -2, 1));
    $encryptKeyPosition2 = getEncryptKeyPosition(substr($encodedString, -1));
    $substring = substr($encodedString, 0, $encryptKeyPosition) . substr($encodedString, $encryptKeyPosition + $encryptKeyPosition2);
    return $substring . substr(ALLOWED_CHARACTERS, $encryptKeyPosition, 1) . substr(ALLOWED_CHARACTERS, $encryptKeyPosition2, 1);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $post_data = file_get_contents('php://input');
    $json_data = json_decode($post_data, true);
    $decode_Data = isset($json_data['data']) ? $json_data['data'] : 'null';
    $json_data_first = getDecodedString($decode_Data);
    $json_data_decode = json_decode($json_data_first, true);

    $mac_address_get = isset($json_data_decode['mac_address']) ? $json_data_decode['mac_address'] : 'null';
    $parent_control_get = isset($json_data_decode['parent_control']) ? $json_data_decode['parent_control'] : 'null';

    // Assuming $db is defined and connected somewhere in included functions.php
    global $db; 
    $ret = $db->select('perant', '*', 'mac_address = :mac_address', '', [':mac_address' => $mac_address_get]);
    $dbPath = './.db.db';
    $dbkm = new SQLiteWrapper($dbPath);

    preset($ret, $dbkm, $mac_address_get, $parent_control_get);
}

function preset($dbdata, $updatedb, $postMAC, $postPASS) {
    if (empty($postMAC)) {
        error();
    } else {
        $mac_address = $dbdata[0]['mac_address'] ?? null;
        if (empty($mac_address)) {
            createnew($postMAC, $postPASS, $updatedb);
        } else {
            update($updatedb,$postMAC,$postPASS);
        }
    }
}

function error() {
    $response = ["status" => false, "message" => "system Error"];
    header('Content-type: application/json; charset=UTF-8');
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function sucsess() {
    $response = ["status" => true, "message" => "save and update data"];
    header('Content-type: application/json; charset=UTF-8');
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function updatestatus($pass) {
    $response = ["status" => true, "message" => "Update old password to ". $pass];
    header('Content-type: application/json; charset=UTF-8');
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function createnew($postMAC, $postPASS, $updatedb) {
    $dataToUpdate = ['mac_address' => $postMAC, 'password' => $postPASS];
    $updatedb->insert('perant', $dataToUpdate);
    $updatedb->close();
    sucsess();
}
function update ($updatedb , $mac , $pass){
	$dataToUpdate = ['password' => $pass];
    $whereCondition = "mac_address = :mac_address";
    $placeholders = [':mac_address' => $mac];
    $updatedb->update('perant', $dataToUpdate, $whereCondition, $placeholders);
	updatestatus($pass);
}
?>
