<?php
include(__DIR__ . '/../includes/functions.php');
$mes = $db->select('framelayout', '*', 'id = :id', '', [':id' => 1]);
error_reporting(E_ALL);
ini_set('display_errors', 1);

$adslayout;

if (empty($mes[0]['layout'] ?? null) || empty($mes[0]['layout'] ?? null)){
	$adslayout = 'layout_0';
}else{
	$adslayout = $mes[0]['layout'];
}


switch ($adslayout) {
    case "layout_0":
    		header("Location: ./frame/frame_0.php");
			exit();
        break;

	case "layout_1":
    		header("Location: ./frame/frame_1.php");
			exit();
        break;

	case "layout_2":
    		header("Location: ./frame/frame_2.php");
			exit();
        break;

	case "layout_3":
    		header("Location: ./frame/frame_3.php");
			exit();
        break;

	case "layout_4":
    		header("Location: ./frame/frame_4.php");
			exit();
        break;

	case "layout_5":
    		header("Location: ./frame/frame_5.php");
			exit();
        break;

    default:
    		header("Location: ./frame/frame_6.php");
			exit();
        break;
}

?>
