<?php
include(__DIR__ . '/../includes/functions.php');
$res = $db->select('dns', '*', '', '');
$rowsJson = array();

foreach ($res as $row) {
    $row_array['rtxnames'] = $row['title']; 
    $row_array['rtxurls'] = $row['url']; 
    array_push($rowsJson, $row_array); 
}
$final = json_encode($rowsJson, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$output_json = '{"dns_backup":"'.Encryption::runfake().'","portals":' . $final . ',"url_backup":"'.Encryption::runfake().'"}';
header('Content-type: application/json; charset=UTF-8');
$json = ["piterparker" => Encryption::run($output_json)]; 
echo json_encode($json, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>
