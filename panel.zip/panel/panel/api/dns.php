<?php
session_start();
error_reporting(0);
$db = new SQLite3('./.db.db');
$res = $db->query('SELECT * FROM dns'); 
$rows = array();
$rowsn = array();
$json_response = array(); 
    
while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
	$row_array['name'] = $row['title']; 
	$row_array['url'] = $row['url']; 
	array_push($json_response,$row_array);  
}

function encr($data,$keyo,$keyt) {
        $key = $keyo.$keyt;
        $encrypted = openssl_encrypt($data, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, 'R4tghjg^425(@#Gg');
        $encrypted_hex = bin2hex($encrypted);
		$reversed_text = strrev($keyo);
        return $encrypted_hex.$reversed_text;
}

function generateRandomKeyfirst() {
    if (!isset($_SESSION['random_key'])) {
        $_SESSION['random_key'] = substr(bin2hex(random_bytes(16)), 0, 16);
    }
    return substr($_SESSION['random_key'], 0, 16);
}

$mykeyone = generateRandomKeyfirst();

$final = json_encode($json_response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$mainencrypt = encr($final,$mykeyone,$mykeyone);
$addkeys = $mainencrypt;

header('Content-type: application/json; charset=UTF-8');
echo $addkeys;
session_destroy();
?>