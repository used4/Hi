<?php
include(__DIR__ . '/../includes/functions.php');
$mes = $db->select('sports', '*', 'id = :id', '', [':id' => 1]);

$headerName = $mes[0]['header_n'];
$bdColour = str_replace("#", "", $mes[0]['border_c']);
$bgColour = str_replace("#", "", $mes[0]['background_c']);
$txtColour = str_replace("#", "", $mes[0]['text_c']);
$days = $mes[0]['days'];
$key = $mes[0]['api'];

$url = "https://www.tvsportguide.com/widget/$key?filter_mode=all&filter_value=&days=$days&heading=$headerName&border_color=custom&autoscroll=1&prev_nonce=a7242d2019&custom_colors=$bdColour,$bgColour,$txtColour";
$response = file_get_contents($url);
$response = str_replace('<i class="gfx tvm-wlogo" target="_blank" style="display: inline-block !important;"></i>','',$response);
$response = str_replace('Presented by','',$response);
$response = str_replace('%%sitename%% %%page%% %%sep%% %%sitedesc%%','Sport Guide',$response);
echo $response;
                                                                        