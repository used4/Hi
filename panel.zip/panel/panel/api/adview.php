<?php
include(__DIR__ . '/../includes/functions.php');
$mes = $db->select('adssettings', '*', 'id = :id', '', [':id' => 1]);
error_reporting(E_ALL);
ini_set('display_errors', 1);

$adstype;

if (empty($mes[0]['adstype'] ?? null) || empty($mes[0]['adstype'] ?? null)){
	$adstype = 'auto';
}else{
	$adstype = $mes[0]['adstype'];
}


switch ($adstype) {
    case "auto":
    		header("Location: auto_ads.php");
			exit();
        break;
	case "manual":
    		header("Location: manual_ads.php");
			exit();
        break;
    default:
    		header("Location: auto_ads.php");
			exit();
        break;
}

?>
