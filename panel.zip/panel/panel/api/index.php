<?php
include(__DIR__ . '/../includes/functions.php');
$ret = $db->select('menualuser', '*', 'username = :username', '', [':username' => $_GET['username']]);

if(paneluser($ret)){
	outecho(1);
}else{
	dnsuser($res);
}

function dnsuser(){
    $dbz = new SQLite3('./.db.db');
    $resz = $dbz->query('SELECT * FROM dns');
    $activeDnsFound = false;
    $maincall = "/player_api.php?username={$_GET['username']}&password={$_GET['password']}";
    while ($row = $resz->fetchArray(SQLITE3_ASSOC)) {
        $dns = $row['url'];
        $api_link = $dns . $maincall;
        $api_req = calllink::run($api_link);
        $result = $api_req;
        if ($result["result"] == "success") {
            if (isset($result["data"]->user_info->auth)) {
                if ($result["data"]->user_info->auth != 0) {
                    if ($result["data"]->user_info->status == "Active") {
                       	
                    	outecho(1);
                    
                        $activeDnsFound = true;
                        break; 
                    }else{
                    
                    
                    }
                } else {
                   
                }
            }
        } else {
        
        }
	}

	if (!$activeDnsFound) {
    	outecho(2);
	}

    
}


function paneluser($dbdata){
	$expired = null;
	$id = $dbdata[0]['id'];
    $title = $dbdata[0]['title'];
    $username = $dbdata[0]['username'];
    $password = $dbdata[0]['password'];
    $expired = $dbdata[0]['expire_date'];

	$expiredT = (time() > strtotime(@$expired));
	if ($expiredT) {$expired = 0;}else{$expired = 1;}

	if (isset($_GET['username']) && isset($_GET['password']) && $_GET['username'] == $username && $_GET['password'] == $password && $expired >= 1) {
    	return true;
	}else{
		return false;
	}

}


function outecho($status){
$response = null;
    if($status == 1){
        $response = [ "status" => "success","data" => "Login successful."];
    }else if ($status == 2){
        $response = [ "status" => "unsuccess","data" => "Invalid username/password or account has expired."];
    }
 	$final = json_encode($response);
	$json = ["peterparker" => Encryption::run($final)]; 
header('Content-type: application/json; charset=UTF-8');
echo json_encode($json, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

?>