<?php

$api_key = '6b8e3eaa1a03ebb45642e9531d8a76d2';

if (isset($_GET['key'])) {
    $movie_id = $_GET['key'];

    $movie_details_url = "https://api.themoviedb.org/3/movie/$movie_id?api_key=$api_key";
    $movie_details_response = file_get_contents($movie_details_url);
    
    if ($movie_details_response !== false) {
        $movie_details_data = json_decode($movie_details_response, true);

        $imdb_id = isset($movie_details_data['imdb_id']) ? $movie_details_data['imdb_id'] : null;
        if ($imdb_id !== null) {
            header("Location: https://www.imdb.com/title/$imdb_id/");
			exit();
        } else {
            echo "IMDB not found for this movie.";
        }
    } else {
        echo "Failed to fetch movie details.";
    }
} else {
    echo "Movie ID not provided.";
}

?>
