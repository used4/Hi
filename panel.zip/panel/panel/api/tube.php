<?php

// Your TMDB API key
$api_key = '6b8e3eaa1a03ebb45642e9531d8a76d2';

// Check if the movie ID is provided in the URL parameter
if (isset($_GET['key'])) {
    // Extract movie ID from URL parameter
    $movie_id = $_GET['key'];

    // Fetch movie details including trailer
    $movie_details_url = "https://api.themoviedb.org/3/movie/$movie_id/videos?api_key=$api_key";
    $movie_details_response = file_get_contents($movie_details_url);
    
    if ($movie_details_response !== false) {
        $movie_details_data = json_decode($movie_details_response, true);

        $trailer_key = null;

        if (isset($movie_details_data['results']) && is_array($movie_details_data['results'])) {
            foreach ($movie_details_data['results'] as $result) {
                if ($result['type'] === 'Trailer') {
                    $trailer_key = $result['key'];
                    break;
                }
            }
        }

        if ($trailer_key !== null) {
            echo "<iframe width='100%' height='100%' src='https://www.youtube.com/embed/$trailer_key?autoplay=1&mute=1&loop=1' frameborder='0' allowfullscreen></iframe>";
        } else {
            echo "Trailer not found for this movie.";
        }
    } else {
        echo "Failed to fetch movie details.";
    }
} else {
    echo "Movie ID not provided.";
}

?>
