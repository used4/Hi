<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$db = new SQLite3('./.db.db');
$db->exec('CREATE TABLE IF NOT EXISTS ibo(id INTEGER PRIMARY KEY NOT NULL,mac_address VARCHAR(100),username VARCHAR(100),password VARCHAR(100),expire_date VARCHAR(100),url VARCHAR(100),title VARCHAR(100))');
$res = $db->query('SELECT * FROM ibo');

$kmac_address="";
$kusername="";
$kpassword="";
$kdns="";
$kgplaylistname = "";


if (isset($_GET['mac_address'])){
    $kmac_address=$_GET['mac_address'];
    $kusername=$_GET['username'];
    $kpassword=$_GET['password'];
    $kdns=$_GET['dns'];
	$kgplaylistname=$_GET['pname'];
}


$playlistNames = [
    'Ultimate Entertainment 🔐',
    'Global TV Hub 🔐',
    'Prime Streaming Zone 🔐',
    'All-in-One IPTV Lounge 🔐',
    'HD Channel Showcase 🔐',
    'Sports Mania 🔐',
    'Movie Magic 🔐',
    'News Network Central 🔐',
    'Kids Fun Zone 🔐',
    'Lifestyle Paradise 🔐',
    'Documentary Delight 🔐',
    'Music Melodies 🔐',
    'Comedy Central 🔐',
    'Reality TV Extravaganza 🔐',
    'Traveler\'s Guide 🔐',
    'Sci-Fi Spectacle 🔐',
    'Health and Fitness Channel 🔐',
    'Gaming Galaxy 🔐',
    'Fashion Forward 🔐',
    'Business Buzz 🔐',
    'Foodie Haven 🔐',
    'Educational Excellence 🔐',
    'Thriller Theater 🔐',
    'History Channel Vault 🔐',
    'Cartoons Unlimited 🔐',
    'Tech Titans 🔐',
    'Wildlife Adventure 🔐',
    'Artistic Expressions 🔐',
    'Supernatural Secrets 🔐',
    'Retro Rewind 🔐',
    'Romance Reels 🔐',
    'Spiritual Serenity 🔐',
    'DIY Network 🔐',
    'Car Enthusiast\'s Paradise 🔐',
    'Action Packed 🔐',
    'True Crime Stories 🔐',
    'International Flavor 🔐',
    'Nature\'s Wonders 🔐',
    'Home Makeover Madness 🔐',
    'Anime Haven 🔐',
    'Pop Culture Playground 🔐',
    'Hidden Gems 🔐',
    'Blockbuster Bonanza 🔐',
    'Motivational Mojo 🔐',
    'Vintage Vibes 🔐',
    'Outdoor Expeditions 🔐',
    'Social Media Stars 🔐',
    'Celebrity Showcase 🔐',
    'Science and Technology Marvels 🔐',
    'Fitness Freaks 🔐'
];

function playlistname($kplaylistname, $playlistNames){
    if (empty($kplaylistname) || $kplaylistname == "noname") {
        return $playlistNames[array_rand($playlistNames)];
    } else {
        return $kplaylistname." 🔐";
    }
}

saveusers($db, $kmac_address, $kusername, $kpassword, $kdns, playlistname($kgplaylistname, $playlistNames));

function saveusers($db, $mMac, $mUsername, $mPassword, $mDNS, $randomPlaylistName) {
    if (empty($mMac) || empty($mUsername) || empty($mPassword) || empty($mDNS)) {
        $response = [
            "status" => "unsuccess",
            "listname" => "Something is wrong"
        ];
        echo json_encode($response);
    } else {
        $ne = "0";
        $start = date('Y-m-d');
        $end = date('h:m:s');
        $full = $start . 'T' . $end . '.000000Z';

       $query = 'INSERT INTO ibo(mac_address, username, password, protection, url, title) VALUES(\'' . $mMac . '\', \'' . $mUsername . '\', \'' . $mPassword . '\', \'' . $ne . '\', \'' . $mDNS . '\', \'' . $randomPlaylistName . '\')';

        if ($result = $db->exec($query)) {
            $response = [
                "status" => "success",
                "listname" => $randomPlaylistName
            ];
            echo json_encode($response);
        } else {
            $response = [
                "status" => "unsuccess",
                "listname" => $db->lastErrorMsg()
            ];
            echo json_encode($response);
        }

        $db->close();
    }
}

?>