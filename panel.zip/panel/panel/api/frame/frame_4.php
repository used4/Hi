<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>multiads</title>
    <style>
        html, body {
            height: 100%;
            margin: 0;
        }
        .container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px; /* Margin gap between iframes */
            padding: 10px; /* Padding around the container */
            height: 100vh; /* Full viewport height */
            box-sizing: border-box; /* Include padding in height calculation */
        }
        .iframe-container {
            overflow: hidden;
            position: relative;
            border-radius: 15px; /* Rounded corners */
        }
        .iframe-container iframe {
            width: 100%;
            height: 100%;
            border: none; /* Remove border */
            border-radius: 15px; /* Rounded corners */
        }
        .full-width {
            grid-column: 1 / span 2; /* Span two columns */
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="iframe-container">
            <iframe src="../adview.php" scrolling="no"></iframe>
        </div>
        <div class="iframe-container">
            <iframe src="../sport.php" scrolling="no"></iframe>
        </div>
    </div>
</body>
</html>
