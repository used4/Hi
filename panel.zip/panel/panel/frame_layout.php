<?php 
include ('includes/header.php');
$table_name = 'framelayout';
$page_name = 'frame_layout';
$data = ['layout' => 'layout_0'];
$db->insertIfEmpty($table_name, $data);
$res = $db->select($table_name, '*', '', '');

if(isset($_POST['submit'])){
	unset($_POST['submit']);
	$updateData = $_POST;
	$db->update($table_name, $updateData, 'id = :id',[':id' => 1]);
	echo "<script>window.location.href='". $page_name.".php?status=1'</script>";
}

function curruntvaleu($res){
    $getvalue = $res[0]['layout'];
    if($getvalue == 'layout_0'){
        return " layout [1]";
    } else if ($getvalue == 'layout_1'){
        return " layout [2]";
    } else if ($getvalue == 'layout_2'){
        return " layout [3]";
    } else if ($getvalue == 'layout_3'){
        return " layout [4]";
    } else if ($getvalue == 'layout_4'){
        return " layout [5]";
    } else if ($getvalue == 'layout_5'){
        return " layout [6]";
    } else{
        return " layout [1]]";
    }
}
?>

?>

        <div class="col-md-12 mx-auto ctmain-table">
            <div class="card-body">
                <div class="card text-white ctcard">
                    <div class="card-header card-header-warning">
                        <center>
                            <h2><i class="icon icon-bullhorn"></i> Frame Ads layout</h2>
                        </center>
                    </div>
                    
           <div class="card-body">
                <form method="post">
                    <div class="form-group ctinput">
                        <label class="form-label"> Current layout :</label>
                        <label><?php echo curruntvaleu($res); ?></label>
                    </div>
                    <div class="form-group ctinput">
                        <label class="form-label">Choose layout </label>
                        <select id="layout" name="layout">
                            <option value="layout_0">layout 1</option>
                            <option value="layout_1">layout 2</option>
                            <option value="layout_2">layout 3</option>
                            <option value="layout_3">layout 4</option>
                            <option value="layout_4">layout 5</option>
                            <option value="layout_5">layout 6</option>
                        </select>
                    </div>
                    <div class="form-group ctinputform-group">
                        <center>
                            <button class="btn btn-info" name="submit" type="submit">
                                <i class="icon icon-check"></i> Submit
                            </button>
                        </center>
                    </div>
                </form>
            </div>       


	<div class="grid-container">
        <div class="grid-item">
            <img src="./frame/frm_0.resized.png" alt="Image 1">
            <div class="image-text">layout 1 [Auto / Manual / Sport guide]</div>
        </div>
        <div class="grid-item">
            <img src="./frame/frm_1.resized.png" alt="Image 2">
            <div class="image-text">layout 2 [Auto / Manual / League widget]</div>
        </div>
        <div class="grid-item">
            <img src="./frame/frm_2.resized.png" alt="Image 3">
            <div class="image-text">layout 3 [Auto / Sport guide / League widget]</div>
        </div>
        <div class="grid-item">
            <img src="./frame/frm_3.resized.png" alt="Image 1">
            <div class="image-text">layout 4 [Auto / Manual]</div>
        </div>
        <div class="grid-item">
            <img src="./frame/frm_4.resized.png" alt="Image 2">
            <div class="image-text">layout 5 [Auto / Sport guide]</div>
        </div>
        <div class="grid-item">
            <img src="./frame/frm_5.resized.png" alt="Image 3">
            <div class="image-text">layout 6 [Manual / Sport guide]</div>
        </div>
    </div>


                    </div>
                </div>
            </div>
        </div>
<style>
        .grid-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px; /* Adjust the gap between images */
            padding: 10px;
        }
        .grid-item {
            text-align: center;
        }
        .grid-item img {
            max-width: 100%;
            height: auto;
        }
        .image-text {
            margin-top: 5px;
            font-size: 16px;
            color: #fff;
        }
    </style>
<?php include ('includes/footer.php');?>