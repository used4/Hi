<?php 
include ('includes/header.php');

//table name
$table_name = "ibo";
$page = "mac_users.php";

//table call
$res = $db->select($table_name, '*', '', '');

//update call
@$resU = $db->select($table_name, '*', 'id = :id', '', [':id' => $_GET['update']]);

if(isset($_POST['submitU'])){
	unset($_POST['submitU']);
	$updateData = $_POST;
	$db->update($table_name, $updateData, 'id = :id',[':id' => $_GET['update']]);
	echo "<script>window.location.href='".$page."?status=1'</script>";
}//submit new
if (isset($_POST['submit'])){
	unset($_POST['submit']);
	$db->insert($table_name, $_POST);
	$db->close();
	echo "<script>window.location.href='".$page."?status=1'</script>";
}
?>
<script>
document.addEventListener("DOMContentLoaded", function() {
    var macAddressInput = document.getElementById("mac_address");

    macAddressInput.addEventListener("input", function(e) {
        var value = e.target.value;
        value = value.replace(/[^a-fA-F0-9]/g, "").toUpperCase();

        var formattedValue = "";
        for (var i = 0; i < value.length; i++) {
            formattedValue += value[i];
            if ((i + 1) % 2 === 0 && i < value.length - 1) {
                formattedValue += ":";
            }
        }

        e.target.value = formattedValue;
    });
});
</script>
<script>
function extract(event) {
    event.preventDefault(); // Prevent page refresh

    var m3uLink = document.getElementById("m3u_address").value;

    // Extract server URL
    var serverUrl = m3uLink.split("/get.php")[0];
    document.getElementById("url").value = serverUrl;

    // Extract username
    var username = getParameterByName("username", m3uLink);
    document.getElementById("username").value = username;

    // Extract password
    var password = getParameterByName("password", m3uLink);
    document.getElementById("password").value = password;
}

function getParameterByName(name, url) {
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return "";
    if (!results[2]) return "";
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}
</script>
<div class="col-md-8 mx-auto ctmain-table">
    <div class="card-body">
        <div class="card ctcard">
            <div class="card-header card-header-warning">
                <center>
                    <h3><i class="icon icon-bullhorn"></i> Update User</h3>
                </center>
            </div>
            <div class="card-body">
                <form>
                    <div class="form-group ctinput">
                        <label class="control-label" for="mac_address">
                            <strong>M3U Extractor</strong>
                        </label>
                        <div class="input-group">
                            <input class="form-control" id="m3u_address" name="m3u_address" placeholder="Enter M3U Link"
                                type="text" required />
                            <br>
                            <button class="btn btn-success btn-icon-split" id="extract_button" onclick="extract(event)">
                                <span class="icon text-white-50"><i class="fa fa-expand"></i></span><span
                                    class="text">extract</span>
                            </button>
                        </div>
                    </div>
                    <div>
                </form>
            </div>
            <div class="card-body">
                <form method="post">
                    <div class="form-group ctinput">
                        <label class="form-label" for="mac_address">Mac address</label>
                        <input class="form-control" id="mac_address" name="mac_address" value="<?=$resU[0]['mac_address'] ?>" placeholder="Mac address"
                            type="text" required />
                    </div>
                    <div class="form-group ctinput">
                        <label class="form-label">Protect this playlist </label>
                        <select id="protection" name="protection"  required>
                            <option value="1">YES</option>
                            <option value="0">NO</option>
                        </select>
                    </div>         
                    <div class="form-group ctinput">
                        <label class="form-label" for="title">Server Name</label>
                        <input class="form-control" id="title" name="title" value="<?=$resU[0]['title'] ?>" placeholder="Server Name" type="text"
                            required />
                    </div>
                    <div class="form-group ctinput">
                        <label class="form-label" for="url">DNS</label>
                        <input class="form-control" id="url" name="url" value="<?=$resU[0]['url'] ?>" placeholder="Enter DNS" type="text" id="url"
                            required />
                    </div>
                    <div class="form-group ctinput">
                        <label class="form-label" for="username">Username</label>
                        <input class="form-control" id="username" name="username" value="<?=$resU[0]['username'] ?>" placeholder="Enter Username"
                            type="text" id="username" required />
                    </div>
                    <div class="form-group ctinput">
                        <label class="form-label" for="password">Password</label>
                        <input class="form-control" id="password" name="password" value="<?=$resU[0]['password'] ?>" placeholder="Enter Password"
                            type="text" id="password" required />
                    </div>
                    <div class="form-group ctinput">
                        <center>
                            <button class="btn btn-info" name="submitU" type="submit">
                                <i class="icon icon-check"></i> Submit
                            </button>
                        </center>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    var protectionValue = "<?=$resU[0]['protection']?>";
    var protectionSelect = document.getElementById('protection');
    protectionSelect.value = protectionValue;
</script>                        
<?php include ('includes/footer.php');?>
</body>

</html>