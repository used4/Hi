<?php
// check_all_playlist_records.php
$db_file = __DIR__ . "/.db.db";

try {
    $db = new PDO("sqlite:$db_file");
    
    echo "=== TODOS LOS REGISTROS DE PLAYLIST ===\n\n";
    
    $stmt = $db->query("SELECT * FROM playlist ORDER BY id DESC");
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "TOTAL DE REGISTROS: " . count($records) . "\n\n";
    
    foreach ($records as $record) {
        echo "ID: {$record['id']}\n";
        echo "MAC: {$record['mac_address']}\n";
        echo "Usuario: {$record['username']}\n";
        echo "Password: {$record['password']}\n";
        echo "is_demo: {$record['is_demo']}\n";
        echo "demo_start: {$record['demo_start']}\n";
        echo "demo_duration: {$record['demo_duration']}\n";
        echo "last_used: " . date('Y-m-d H:i:s', $record['last_used']) . "\n";
        echo "---\n\n";
    }
    
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage();
}