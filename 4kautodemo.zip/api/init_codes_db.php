<?php
$path = __DIR__ . '/codes.db';
$db = new SQLite3($path);

$db->exec("CREATE TABLE IF NOT EXISTS codes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mac_address TEXT NOT NULL,
    codigo TEXT NOT NULL,
    estado INTEGER DEFAULT 0,
    is_demo INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");
