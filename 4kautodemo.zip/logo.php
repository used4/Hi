<?php
session_start();

// Verificação de login
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: index.php');
    exit;
}

include('includes/header.php');

// Caminho do arquivo logo
$uploadDir = __DIR__ . '/img/';
$uploadFile = $uploadDir . 'logo.png';

// Upload da imagem
if (isset($_POST['submit'])) {
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
        $tmpName = $_FILES['logo']['tmp_name'];

        // Verifica se é uma imagem válida
        $check = getimagesize($tmpName);
        if ($check !== false) {
            // Move a imagem enviada para logo.png
            if (move_uploaded_file($tmpName, $uploadFile)) {
                $msg = "<div class='alert alert-success text-center'>✅ Logo actualizado con exito!</div>";
            } else {
                $msg = "<div class='alert alert-danger text-center'>❌ Error al guardar el logo.</div>";
            }
        } else {
            $msg = "<div class='alert alert-warning text-center'>⚠️ archivo inválido.</div>";
        }
    } else {
        $msg = "<div class='alert alert-danger text-center'>📂 Ningún archivo seleccionado.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciamento de Logo</title>
    <style>
       :root {
    --primary-black: #000000;
    --dark-gray: #2c2c2c;
    --medium-gray: #4d4d4d;
    --light-gray: #bfbfbf;
    --extra-light-gray: #f5f5f5;
}
        
        
        .page-container {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        
        .main-content {
            flex: 1;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding-top: 40px;
            padding-bottom: 40px;
        }
        
        .card-custom {
    background: rgba(30, 30, 30, 0.9);
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(200, 200, 200, 0.2);
    overflow: visible;
    width: 100%;
    max-width: 800px;
    margin: 0 auto;
}
        
        .card-header-custom {
    background: linear-gradient(90deg, var(--dark-gray), var(--medium-gray));
    padding: 20px;
    border-bottom: 2px solid var(--light-gray);
    text-align: center;
    color: var(--extra-light-gray);
}
        
        .card-body-custom {
            padding: 30px;
            text-align: center;
        }
        
        .form-control {
            background-color: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 0, 0, 0.3);
            color: white;
            border-radius: 8px;
            padding: 12px 15px;
            transition: all 0.3s;
            height: auto;
            min-height: 45px;
            width: 100%;
            margin-bottom: 20px;
        }
        
        .form-control:focus {
            background-color: rgba(255, 255, 255, 0.15);
            border-color: var(--bright-red);
            box-shadow: 0 0 0 0.2rem rgba(255, 0, 0, 0.25);
            color: white;
        }
        
        .form-label {
            font-weight: 600;
            color: #f8f9fa;
            margin-bottom: 8px;
            display: block;
            font-size: 1.1em;
        }
        
        .btn-custom {
            background: linear-gradient(45deg, var(--primary-black), var(--dark-red));
            border: none;
            border-radius: 8px;
            padding: 12px 30px;
            font-weight: bold;
            color: white;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(255, 0, 0, 0.2);
            margin-top: 15px;
            display: inline-block;
            text-decoration: none;
            text-align: center;
        }
        
        .btn-custom:hover {
            background: linear-gradient(45deg, var(--dark-red), var(--primary-black));
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(255, 0, 0, 0.3);
            color: white;
            text-decoration: none;
        }
        
        h2, h3, h4 {
            font-weight: 700;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }
        
        .emoji {
            font-size: 1.2em;
            margin-right: 8px;
        }
        
        .current-logo {
            margin-bottom: 30px;
        }
        
        .current-logo img {
            max-height: 200px;
            max-width: 100%;
            background: transparent;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 0, 0, 0.3);
        }
        
        /* Alertas estilizados */
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid transparent;
        }
        
        .alert-success {
            background-color: rgba(40, 167, 69, 0.2);
            border-color: rgba(40, 167, 69, 0.3);
            color: #d4edda;
        }
        
        .alert-danger {
            background-color: rgba(220, 53, 69, 0.2);
            border-color: rgba(220, 53, 69, 0.3);
            color: #f8d7da;
        }
        
        .alert-warning {
            background-color: rgba(255, 193, 7, 0.2);
            border-color: rgba(255, 193, 7, 0.3);
            color: #fff3cd;
        }
        
        /* Responsividade para dispositivos móveis */
        @media (max-width: 768px) {
            .main-content {
                padding: 15px;
                padding-top: 20px;
                padding-bottom: 20px;
            }
            
            .card-body-custom {
                padding: 20px;
            }
            
            .card-header-custom {
                padding: 15px;
            }
            
            h2 {
                font-size: 1.5rem;
            }
            
            h3, h4 {
                font-size: 1.3rem;
            }
            
            .btn-custom {
                padding: 10px 20px;
                width: 100%;
            }
            
            .current-logo img {
                max-height: 180px;
            }
        }
        
        @media (max-width: 576px) {
            .card-body-custom {
                padding: 15px;
            }
            
            .form-control {
                padding: 10px;
            }
            
            .current-logo img {
                max-height: 150px;
                padding: 10px;
            }
        }
    </style>
</head>
<body>
<div class="page-container">
    <div class="main-content">
        <div class="card-custom">
            <div class="card-header-custom">
                <h2><span class="emoji">🖼️</span> Gestionarr Logo</h2>
                <p><span class="emoji">📌</span> Envía tu Logo formato .png fondo transparente</p>
            </div>
            
            <div class="card-body-custom">
                <?php if (isset($msg)) echo $msg; ?>
                
                <div class="current-logo">
                    <h4><span class="emoji">🔎</span> Logo Actual</h4>
                    <img src="img/logo.png?<?=time()?>" 
                         alt="Logo atual">
                </div>
                
                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="logo" class="form-label">
                            <span class="emoji">📤</span> Seleccione un nuevo logo:
                        </label>
                        <input type="file" class="form-control" name="logo" id="logo" accept="image/*" required>
                    </div>
                    <button class="btn btn-custom" name="submit" type="submit">
                        <span class="emoji">🚀</span> Enviar / Sustituir Logo
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>
</body>
</html>