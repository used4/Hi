<?php
include ('includes/header.php');

$table_name = 'user';
$page = 'user.php';
$res = $db->select($table_name, '*', '', '');

if(isset($_POST['submit'])){
	unset($_POST['submit']);
	$updateData = $_POST;
	$db->update($table_name, $updateData, 'id = :id',[':id' => 1]);
	session_regenerate_id();
	$_SESSION['loggedin'] = true;
	$_SESSION['name'] = $_POST['username'];
	echo "<script>window.location.href='".$page."?status=1'</script>";
}

?>
<style>
/* Custom control panel styles matching ads.php */
.adm_container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 15px;
}

.adm_title {
    text-align: center;
    margin-bottom: 20px;
    color: var(--light);
}

.adm_card {
    background-color: #2a2a2a;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
    overflow: hidden;
    transition: all 0.3s ease;
}

.adm_card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
}

.adm_card_header {
    background-color: var(--accent-tertiary);
    color: var(--light);
    padding: 15px 20px;
    border-radius: 5px 5px 0 0;
    display: flex;
    align-items: center;
    justify-content: center;
}

[data-theme="light"] .adm_card_header {
    background-color: var(--accent-tertiary);
    color: var(--light);
}

.adm_card_body {
    padding: 20px;
    background-color: #2a2a2a;
    color: var(--light);
}

[data-theme="light"] .adm_card_body {
    background-color: var(--light);
    color: var(--text-dark);
}

.adm_btn {
    display: inline-block;
    font-weight: 400;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    user-select: none;
    border: 1px solid transparent;
    padding: 0.5rem 1rem;
    font-size: 1rem;
    line-height: 1.5;
    border-radius: 0.25rem;
    transition: all 0.15s ease-in-out;
    cursor: pointer;
}

.adm_btn_primary {
    background-color: var(--accent-secondary);
    border-color: var(--accent-tertiary);
    color: var(--light);
}

.adm_btn_primary:hover {
    background-color: var(--accent-tertiary);
    border-color: var(--accent-secondary);
}
</style>

<div class="adm_container">
    <h1 class="adm_title">User Management</h1>
    <div class="adm_card">
        <div class="adm_card_header">
            <h2><i class="icon icon-user"></i> Update Credentials</h2>
        </div>
        <div class="adm_card_body">
            <form method="post">
                <div class="form-group">
                    <label class="form-label">Username</label>
                    <input type="text" class="form-control" name="username" value="<?=$res[0]['username'] ?>">
                </div>

                <div class="form-group">
                    <label class="form-label">Password</label>
                    <input type="text" class="form-control" name="password" value="<?=$res[0]['password'] ?>">
                </div>

                <hr>

                <div class="text-center mt-3">
                    <button type="submit" name="submit" class="adm_btn adm_btn_primary">
                        <i class="icon icon-check"></i> Update Credentials
                    </button>
                </div>
            </form>
        </div>
				</div>
			</div>
		</div>


<?php include ('includes/footer.php'); ?>

</body>
</html>