<?php
// Leer el archivo JSON
$json = file_get_contents('selector.json');

// Decodificar el JSON
$data = json_decode($json, true);

// Verificar si la clave 'mode' existe
if (isset($data['mode'])) {
    // Redirigir al PHP indicado en el JSON
    header('Location: ' . $data['mode']);
    exit;
} else {
    // Si no se encuentra la clave 'mode', puedes redirigir a una página predeterminada o mostrar un error
    echo "No se ha especificado un archivo para redirigir.";
}
?>
